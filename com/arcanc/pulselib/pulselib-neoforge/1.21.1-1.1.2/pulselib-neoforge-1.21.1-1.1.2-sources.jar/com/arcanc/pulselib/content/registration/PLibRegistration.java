/**
 * @author ArcAnc
 * Created at: 27.01.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.registration;

import com.arcanc.pulselib.content.registration.block.TestBlock;
import com.arcanc.pulselib.content.registration.block.block_entity.TestBlockEntity;
import com.arcanc.pulselib.content.registration.entity.TestEntity;
import com.arcanc.pulselib.content.registration.item.TestArmor;
import com.arcanc.pulselib.content.registration.item.TestBlockItem;
import com.arcanc.pulselib.content.registration.item.TestTailItem;
import com.arcanc.pulselib.util.PLibDatabase;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public class PLibRegistration
{
	public static class BlockReg
	{
		public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(PLibDatabase.MOD_ID);
		
		public static final DeferredBlock<TestBlock> TEST_BLOCK = BLOCKS.register("test_block", () -> new TestBlock(
				BlockBehaviour.Properties.of().
						noOcclusion()));
		
		private static void init (@NotNull final IEventBus bus)
		{
			BLOCKS.register(bus);
		}
	}
	
	public static class BETypeReg
	{
		public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(
				BuiltInRegistries.BLOCK_ENTITY_TYPE, PLibDatabase.MOD_ID);
	
		public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TestBlockEntity>> TEST_BLOCK_ENTITY = BLOCK_ENTITIES.register("test_block_entity", () ->
				new BlockEntityType<>(TestBlockEntity :: new, Set.of(BlockReg.TEST_BLOCK.get()), null));
		
		private static void init (@NotNull final IEventBus bus)
		{
			BLOCK_ENTITIES.register(bus);
		}
	}
	
	public static class ItemReg
	{
		public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(PLibDatabase.MOD_ID);
		
		public static final DeferredItem<TestBlockItem> TEST_ITEM = ITEMS.register("test_block", identifier -> new TestBlockItem(
				BlockReg.TEST_BLOCK.get(),
				new Item.Properties()));
		
		public static final DeferredItem<TestArmor> TEST_CHESTPLATE = ITEMS.register("test_chest", identifier -> new TestArmor(
				ArmorMaterials.DIAMOND,
				ArmorItem.Type.CHESTPLATE,
				new Item.Properties().durability(ArmorItem.Type.CHESTPLATE.getDurability(33))));
		
		public static final DeferredItem<TestArmor> TEST_HAT = ITEMS.register("test_hat", identifier -> new TestArmor(
				ArmorMaterials.DIAMOND,
				ArmorItem.Type.HELMET,
				new Item.Properties().durability(ArmorItem.Type.HELMET.getDurability(33))));
		
		public static final DeferredItem<TestArmor> TEST_LEGGINGS = ITEMS.register("test_leggings", identifier -> new TestArmor(
				ArmorMaterials.DIAMOND,
				ArmorItem.Type.LEGGINGS,
				new Item.Properties().durability(ArmorItem.Type.LEGGINGS.getDurability(33))));
		
		public static final DeferredItem<TestTailItem> TEST_TAIL = ITEMS.register("test_tail", identifier -> new TestTailItem(
				new Item.Properties().stacksTo(1)));
		
		private static void init (@NotNull final IEventBus bus)
		{
			ITEMS.register(bus);
		}
	}
	
	public static class EntityTypeReg
	{
		public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, PLibDatabase.MOD_ID);
		
		public static final DeferredHolder<EntityType<?>, EntityType<TestEntity>> TEST_ENTITY = ENTITIES.register("test_entity", key -> EntityType.Builder.of(TestEntity :: new, MobCategory.MISC).
				sized(1, 1).
				clientTrackingRange(5).
				build(key.toString()));
		
		private static void init (@NotNull final IEventBus bus)
		{
			ENTITIES.register(bus);
		}
	}
	
	public static void init(@NotNull final IEventBus bus)
	{
		/*EntityTypeReg.init(bus);
		BlockReg.init(bus);
		BETypeReg.init(bus);
		ItemReg.init(bus);*/
	}
}
