/**
 * @author ArcAnc
 * Created at: 07.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.renderer;


import com.arcanc.pulselib.content.model.baked.PBakedBone;
import com.arcanc.pulselib.content.model.baked.PBakedMesh;
import com.arcanc.pulselib.content.model.baked.PMeshRenderContext;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

@FunctionalInterface
/**
 * Defines the contract for mesh render resolver.
 */
public interface PMeshRenderResolver
{
	/**
	 * Performs the resolve operation.
	 * @param entity the entity to use.
	 * @param stack the stack to use.
	 * @param bone the bone to use.
	 * @param mesh the mesh to use.
	 * @param inherited the inherited to use.
	 * @param partialTick the partial tick to use.
	 * @return the value produced by this operation.
	 */
	PMeshRenderContext resolve(LivingEntity entity,
	                           ItemStack stack,
	                           PBakedBone bone,
	                           PBakedMesh mesh,
	                           PMeshRenderContext inherited,
	                           float partialTick);
}
