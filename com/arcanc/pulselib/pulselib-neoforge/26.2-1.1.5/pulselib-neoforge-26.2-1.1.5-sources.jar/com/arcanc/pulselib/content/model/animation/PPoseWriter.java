/**
 * @author ArcAnc
 * Created at: 05.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.animation;

import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Defines the contract for pose writer.
 */
public interface PPoseWriter
{
	/**
	 * Performs the translation operation.
	 * @param boneIndex the bone index to use.
	 * @param value the value to use.
	 */
	void translation(int boneIndex, Vector3f value);

	/**
	 * Performs the rotation operation.
	 * @param boneIndex the bone index to use.
	 * @param value the value to use.
	 */
	void rotation(int boneIndex, Quaternionf value);

	/**
	 * Performs the scale operation.
	 * @param boneIndex the bone index to use.
	 * @param value the value to use.
	 */
	void scale(int boneIndex, Vector3f value);
}
