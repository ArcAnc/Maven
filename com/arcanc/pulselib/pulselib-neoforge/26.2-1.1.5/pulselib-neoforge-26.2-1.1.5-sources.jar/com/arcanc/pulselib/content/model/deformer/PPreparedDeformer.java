/**
 * @author ArcAnc
 * Created at: 08.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.deformer;

import org.joml.Vector3f;

/**
 * Defines the contract for prepared deformer.
 */
public interface PPreparedDeformer
{
	/**
	 * Performs the deform operation.
	 * @param position the position to use.
	 * @param values the values to use.
	 */
	void deform(Vector3f position, PDeformerValueSource values);
}
