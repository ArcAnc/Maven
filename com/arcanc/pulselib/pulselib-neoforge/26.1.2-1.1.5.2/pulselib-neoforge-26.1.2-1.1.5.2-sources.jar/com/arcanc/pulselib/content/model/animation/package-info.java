/**
 * @author ArcAnc
 * Created at: 27.02.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

@NullMarked
package com.arcanc.pulselib.content.model.animation;

import org.jspecify.annotations.NullMarked;