/**
 * @author ArcAnc
 * Created at: 08.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.deformer;

import com.arcanc.pulselib.util.PLibDatabase;
import com.mojang.serialization.MapCodec;
import net.minecraft.resources.Identifier;
import org.joml.Vector3f;

/**
 * Deforms stretch.
 */
public final class PStretchDeformer implements PMeshDeformer<PStretchDefinition>
{
	public static final PStretchDeformer INSTANCE = new PStretchDeformer();
	private static final float EPSILON = 1.0e-5f;

	/**
	 * Creates an instance of the enclosing type.
	 */
	private PStretchDeformer()
	{
	}

	/**
	 * Performs the id operation.
	 * @return the value produced by this operation.
	 */
	@Override
	public Identifier id()
	{
		return PLibDatabase.rl("stretch");
	}

	/**
	 * Performs the codec operation.
	 * @return the value produced by this operation.
	 */
	@Override
	public MapCodec<PStretchDefinition> codec()
	{
		return PStretchDefinition.CODEC;
	}

	/**
	 * Performs the prepare operation.
	 * @param context the context to use.
	 * @param definition the definition to use.
	 */
	@Override
	public void prepare(PDeformerPrepareContext context, PStretchDefinition definition)
	{
		context.add(new Operation(new Vector3f(definition.origin()), unit(definition.axis()), definition.scale()));
	}

	/**
	 * Performs the unit operation.
	 * @param axis the axis to use.
	 * @return the value produced by this operation.
	 */
	private static Vector3f unit(Vector3f axis)
	{
		Vector3f result = new Vector3f(axis);
		if (result.lengthSquared() < EPSILON * EPSILON)
			throw new IllegalArgumentException("axis must not be zero");
		return result.normalize();
	}

/**
 * Immutable value object representing operation.
 */
	private record Operation(Vector3f origin, Vector3f axis, PChannelReference<Float> scale) implements PPreparedDeformer
	{
		/**
		 * Performs the deform operation.
		 * @param position the position to use.
		 * @param values the values to use.
		 */
		@Override
		public void deform(Vector3f position, PDeformerValueSource values)
		{
			float factor = Math.max(values.resolve(this.scale), EPSILON);
			Vector3f relative = new Vector3f(position).sub(this.origin);
			position.set(relative.fma((factor - 1.0f) * relative.dot(this.axis), this.axis).
					add(this.origin));
		}
	}
}
