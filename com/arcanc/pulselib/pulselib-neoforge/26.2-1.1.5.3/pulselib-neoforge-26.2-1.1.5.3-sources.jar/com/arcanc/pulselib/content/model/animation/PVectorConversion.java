/**
 * @author ArcAnc
 * Created at: 05.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.animation;

import org.joml.Vector3f;

@FunctionalInterface
/**
 * Defines the contract for vector conversion.
 */
public interface PVectorConversion
{
	PVectorConversion IDENTITY = value -> {};

	/**
	 * Performs the apply operation.
	 * @param value the value to use.
	 */
	void apply(Vector3f value);
}
