/**
 * @author ArcAnc
 * Created at: 05.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.animation;

import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Immutable value object representing root motion delta.
 */
public record PRootMotionDelta(
		Vector3f translation,
		Quaternionf rotation)
{
	/**
	 * Performs the identity operation.
	 * @return the value produced by this operation.
	 */
	public static PRootMotionDelta identity()
	{
		return new PRootMotionDelta(new Vector3f(), new Quaternionf());
	}
}
