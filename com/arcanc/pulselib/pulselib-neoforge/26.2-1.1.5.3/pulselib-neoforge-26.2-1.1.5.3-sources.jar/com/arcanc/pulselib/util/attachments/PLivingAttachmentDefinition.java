/**
 * @author ArcAnc
 * Created at: 07.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.util.attachments;


import com.arcanc.pulselib.content.animatable.PAnimationController;
import com.arcanc.pulselib.content.model.baked.PBakedModel;
import com.arcanc.pulselib.content.renderer.modelData.PModelData;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.util.Collection;
import java.util.List;
import java.util.Objects;

/**
 * Immutable value object representing living attachment definition.
 */
public record PLivingAttachmentDefinition(
		PModelData model,
		PLivingAttachmentSource source,
		List<PAttachmentBinding> bindings,
		PLivingMeshRenderResolver renderResolver,
		boolean hideVanilla,
		ControllerProvider controllerProvider)
{
	/**
	 * Creates an instance of the enclosing type.
	 * @param model the model to use.
	 * @param source the source to use.
	 * @param bindings the bindings to use.
	 * @param renderResolver the render resolver to use.
	 * @param hideVanilla the hide vanilla to use.
	 */
	public PLivingAttachmentDefinition(PModelData model,
	                                   PLivingAttachmentSource source,
	                                   List<PAttachmentBinding> bindings,
	                                   PLivingMeshRenderResolver renderResolver,
	                                   boolean hideVanilla)
	{
		this(model, source, bindings, renderResolver, hideVanilla, ControllerProvider.EMPTY);
	}
	
	/**
	 * Creates an instance of the enclosing type.
	 * @param model the model to use.
	 * @param source the source to use.
	 * @param bindings the bindings to use.
	 * @param renderResolver the render resolver to use.
	 * @param hideVanilla the hide vanilla to use.
	 * @param controllerProvider the controller provider to use.
	 */
	public PLivingAttachmentDefinition
	{
		Objects.requireNonNull(model);
		Objects.requireNonNull(source);
		bindings = List.copyOf(Objects.requireNonNull(bindings));
		Objects.requireNonNull(renderResolver);
		Objects.requireNonNull(controllerProvider);
	}
	
	/**
	 * Performs the model data operation.
	 * @return the value produced by this operation.
	 */
	public PModelData modelData()
	{
		return this.model;
	}
	
	/**
	 * Performs the animation controllers operation.
	 * @param entity the entity to use.
	 * @param stack the stack to use.
	 * @param model the model to use.
	 * @param partialTick the partial tick to use.
	 * @return the value produced by this operation.
	 */
	public Collection<PAnimationController<?>> animationControllers(LivingEntity entity, ItemStack stack, PBakedModel model, float partialTick)
	{
		return this.controllerProvider.controllers(entity, stack, model, partialTick);
	}
	
	@FunctionalInterface
/**
 * Defines the contract for controller provider.
 */
	public interface ControllerProvider
	{
		ControllerProvider EMPTY = (entity, stack, model, partialTick) -> List.of();
		
		/**
		 * Performs the controllers operation.
		 * @param entity the entity to use.
		 * @param stack the stack to use.
		 * @param model the model to use.
		 * @param partialTick the partial tick to use.
		 * @return the value produced by this operation.
		 */
		Collection<PAnimationController<?>> controllers(LivingEntity entity, ItemStack stack, PBakedModel model, float partialTick);
	}
}
