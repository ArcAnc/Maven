/**
 * @author ArcAnc
 * Created at: 05.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.animation;

import java.util.List;

/**
 * Immutable value object representing animation track.
 */
public record PAnimationTrack<T>(PAnimationChannelType<T> channel, List<PKeyframe<T>> keyframes)
{
	/**
	 * Creates an instance of the enclosing type.
	 * @param channel the channel to use.
	 * @param keyframes the keyframes to use.
	 */
	public PAnimationTrack
	{
		keyframes = List.copyOf(keyframes);
	}
}
