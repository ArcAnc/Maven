/**
 * @author ArcAnc
 * Created at: 08.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.player.deformer.PModelPartCubes;
import net.minecraft.client.model.geom.ModelPart;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;

/**
 * Applies PulseLib integration to {@code ModelPart}.
 */
@Mixin(ModelPart.class)
public class ModelPartCubesMixin implements PModelPartCubes
{
	@Shadow @Final
	private List<ModelPart.Cube> cubes;

	/**
	 * Performs the pulselib$cubes operation.
	 * @return the value produced by this operation.
	 */
	@Override
	public List<ModelPart.Cube> pulselib$cubes()
	{
		return this.cubes;
	}
}
