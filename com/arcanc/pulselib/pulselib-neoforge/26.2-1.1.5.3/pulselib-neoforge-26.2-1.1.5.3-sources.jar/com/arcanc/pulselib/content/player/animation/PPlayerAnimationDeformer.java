/**
 * @author ArcAnc
 * Created at: 09.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation;

import com.arcanc.pulselib.content.model.deformer.PDeformerStack;

import java.util.Objects;

/**
 * Immutable value object representing player animation deformer.
 */
public record PPlayerAnimationDeformer(
		PPlayerPart part,
		PDeformerStack stack,
		PPlayerAnimationDeformerValueSource values)
{
	/**
	 * Creates an instance of the enclosing type.
	 * @param part the part to use.
	 * @param stack the stack to use.
	 * @param values the values to use.
	 */
	public PPlayerAnimationDeformer
	{
		Objects.requireNonNull(part);
		Objects.requireNonNull(stack);
		Objects.requireNonNull(values);
	}
}
