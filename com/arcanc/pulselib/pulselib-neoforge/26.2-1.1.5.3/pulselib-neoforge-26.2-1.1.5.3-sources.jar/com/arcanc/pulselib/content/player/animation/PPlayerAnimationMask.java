/**
 * @author ArcAnc
 * Created at: 30.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation;

import net.minecraft.world.entity.player.Player;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;

@FunctionalInterface
/**
 * Defines the contract for player animation mask.
 */
public interface PPlayerAnimationMask
{
	/**
	 * Performs the contains operation.
	 * @param player the player to use.
	 * @param part the part to use.
	 * @param partialTick the partial tick to use.
	 * @return the value produced by this operation.
	 */
	boolean contains(Player player, PPlayerPart part, float partialTick);

	/**
	 * Performs the of operation.
	 * @param parts the parts to use.
	 * @return the value produced by this operation.
	 */
	static PPlayerAnimationMask of(PPlayerPart... parts)
	{
		Objects.requireNonNull(parts);
		EnumSet<PPlayerPart> allowed = EnumSet.noneOf(PPlayerPart.class);
		Arrays.stream(parts).forEach(part -> allowed.add(Objects.requireNonNull(part)));
		return of(allowed);
	}

	/**
	 * Performs the of operation.
	 * @param parts the parts to use.
	 * @return the value produced by this operation.
	 */
	static PPlayerAnimationMask of(Set<PPlayerPart> parts)
	{
		Set<PPlayerPart> allowed = Set.copyOf(parts);
		return (player, part, partialTick) -> allowed.contains(part);
	}
}
