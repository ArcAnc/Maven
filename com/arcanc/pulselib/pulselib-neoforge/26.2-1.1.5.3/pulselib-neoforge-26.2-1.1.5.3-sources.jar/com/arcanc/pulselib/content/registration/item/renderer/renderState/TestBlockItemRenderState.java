/**
 * @author ArcAnc
 * Created at: 28.02.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.registration.item.renderer.renderState;


import com.arcanc.pulselib.content.registration.item.TestBlockItem;
import com.arcanc.pulselib.content.renderer.base.PItemRenderState;

/**
 * Stores the test block item render state.
 */
public class TestBlockItemRenderState extends PItemRenderState.Impl<TestBlockItem>
{
}
