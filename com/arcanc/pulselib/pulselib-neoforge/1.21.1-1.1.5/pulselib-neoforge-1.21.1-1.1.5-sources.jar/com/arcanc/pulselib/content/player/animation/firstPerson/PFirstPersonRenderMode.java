/**
 * @author ArcAnc
 * Created at: 11.09.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation.firstPerson;

/**
 * Enumerates the available first person render mode values.
 */
public enum PFirstPersonRenderMode
{
	VANILLA,
	ANIMATED,
	HIDDEN
}
