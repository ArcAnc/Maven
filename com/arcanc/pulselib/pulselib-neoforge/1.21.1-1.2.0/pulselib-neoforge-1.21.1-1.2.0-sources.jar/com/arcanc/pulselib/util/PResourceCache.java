/**
 * @author ArcAnc
 * Created at: 22.09.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.util;

import com.arcanc.pulselib.content.model.PTextureReference;
import com.arcanc.pulselib.plugin.PulsePluginManager;
import com.arcanc.pulselib.content.model.resource.PModelResource;
import com.arcanc.pulselib.util.helpers.PLibRenderHelper;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Owns registered model resources and the PulseLib texture atlas.
 */
public final class PResourceCache
{
	private static final String SPRITE_PREFIX = "runtime/";
	/**
	 * Runtime resource location of the PulseLib texture atlas.
	 */
	public static final ResourceLocation ATLAS_LOCATION = PLibDatabase.rl("textures/atlas.png");
	/**
	 * Resource location of the atlas source definition.
	 */
	@ApiStatus.Internal
	public static final ResourceLocation ATLAS_FILE_LOCATION = PLibDatabase.rl("atlas");
	private static @Nullable TextureAtlas textures;
	private static final Map<ResourceLocation, PModelResource> resources = new LinkedHashMap<>();

	private PResourceCache()
	{
	}

	/**
	 * Returns the currently resolved PulseLib texture atlas.
	 *
	 * @return the currently resolved PulseLib texture atlas
	 */
	public static TextureAtlas getTextureAtlas()
	{
		if (textures == null)
			textures = PLibRenderHelper.mc().getModelManager().getAtlas(ATLAS_LOCATION);
		return textures;
	}

	/**
	 * Returns the canonical model resource declarations used by model loading.
	 *
	 * @return the canonical model resource declarations used by model loading
	 */
	@ApiStatus.Internal
	public static Map<ResourceLocation, PModelResource> getResourceCache()
	{
		return resources;
	}

	/**
	 * Clears registered model resources and cached texture-resolution state.
	 */
	@ApiStatus.Internal
	public static void clear()
	{
		resources.clear();
		textures = null;
	}

	/**
	 * Rebuilds the logical model-resource registrations before any model or
	 * atlas reload work consumes them.
	 */
	@ApiStatus.Internal
	public static void reloadRegistrations()
	{
		Map<ResourceLocation, PModelResource> staged = new LinkedHashMap<>();
		PulsePluginManager.get().registerModels(staged);
		resources.clear();
		resources.putAll(staged);
		textures = null;
		PLibDatabase.LOGGER.info("PulseLib resource reload: collected {} model declarations", resources.size());
	}

	/**
	 * Discards the atlas instance while retaining logical model registrations.
	 */
	@ApiStatus.Internal
	public static void invalidateTextureAtlas()
	{
		textures = null;
	}

	/**
	 * Resolves a model texture reference through its registered overrides.
	 *
	 * @param modelId the canonical model identifier
	 * @param textureReference the source-model texture reference used for override lookup
	 * @return the namespaced resource or registry identifier
	 */
	public static ResourceLocation resolve(ResourceLocation modelId, String textureReference)
	{
		PModelResource resource = resources.get(modelId);
		if (resource == null)
			throw new IllegalStateException("No resources registered for model " + modelId);
		ResourceLocation texture = Optional.ofNullable(resource.textures().get(PTextureReference.normalize(textureReference))).
				orElseThrow(() -> new IllegalStateException(
						"No texture registered for model " + modelId + ": " + textureReference));
		return spriteId(texture);
	}

	/**
	 * Converts a texture resource location into the corresponding atlas sprite identifier.
	 *
	 * @param texture the texture resource location
	 * @return the namespaced resource or registry identifier
	 */
	@ApiStatus.Internal
	public static ResourceLocation spriteId(ResourceLocation texture)
	{
		return PLibDatabase.rl(SPRITE_PREFIX + texture.getNamespace() + "/" + texture.getPath());
	}

}
