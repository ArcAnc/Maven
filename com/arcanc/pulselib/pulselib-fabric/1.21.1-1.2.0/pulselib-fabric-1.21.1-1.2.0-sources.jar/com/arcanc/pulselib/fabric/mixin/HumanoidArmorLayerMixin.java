/**
 * @author ArcAnc
 * Created at: 12.10.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.fabric.mixin;

import com.arcanc.pulselib.content.player.deformer.PPlayerMeshDeformers;
import com.arcanc.pulselib.util.attachments.PLivingAttachments;
import com.arcanc.pulselib.util.attachments.humanoid.armor.PArmorModelProvider;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;

/**
 * Integrates PulseLib armor animation, attachment replacement and player deformation with the loader armor
 * render path.
 */
@Mixin (class_970.class)
public abstract class HumanoidArmorLayerMixin
{
	/**
	 * Selects and animates the armor model supplied by a PulseLib armor provider.
	 *
	 * @param poses the poses
	 * @param buffers the vanilla vertex buffer source
	 * @param entity the entity being animated or rendered
	 * @param slot the equipment slot being inspected
	 * @param light the packed block and sky light coordinates
	 * @param model the model
	 * @param original the original implementation or unmodified value supplied by the render hook
	 */
	@WrapMethod (method = "renderArmorPiece")
	private void pulselib$armorModel(class_4587 poses, class_4597 buffers, class_1309 entity,
	                                 class_1304 slot, int light, class_572<?> model, Operation<Void> original)
	{
		var stack = entity.method_6118(slot);
		if (stack.method_7909() instanceof PArmorModelProvider provider)
			model = Objects.requireNonNull(provider.getPulseArmorModel(entity, stack, slot, model), "Pulse armor model");
		original.call(poses, buffers, entity, slot, light, model);
	}

	/**
	 * Skips vanilla armor geometry replaced by an eligible living attachment.
	 *
	 * @param poses the poses
	 * @param buffers the vanilla vertex buffer source
	 * @param entity the entity being animated or rendered
	 * @param slot the equipment slot being inspected
	 * @param light the packed block and sky light coordinates
	 * @param model the model
	 * @param callback the Mixin callback used to inspect or replace the intercepted result
	 */
	@Inject (method = "renderArmorPiece", at = @At ("HEAD"), cancellable = true)
	private void pulselib$hideVanillaArmor(class_4587 poses, class_4597 buffers, class_1309 entity,
	                                       class_1304 slot, int light, class_572<?> model, CallbackInfo callback)
	{
		if (PLivingAttachments.hidesVanillaArmor(entity.method_6118(slot), slot, entity))
			callback.cancel();
	}

	/**
	 * Applies provider animation and active player deformation to the selected armor model.
	 *
	 * @param poses the poses
	 * @param buffers the vanilla vertex buffer source
	 * @param entity the entity being animated or rendered
	 * @param slot the equipment slot being inspected
	 * @param light the packed block and sky light coordinates
	 * @param model the model
	 * @param callback the Mixin callback used to inspect or replace the intercepted result
	 */
	@Inject (method = "renderArmorPiece", at = @At (value = "INVOKE",
		target = "Lnet/minecraft/client/renderer/entity/layers/HumanoidArmorLayer;setPartVisibility(Lnet/minecraft/client/model/HumanoidModel;Lnet/minecraft/world/entity/EquipmentSlot;)V", shift = At.Shift.AFTER))
	private void pulselib$deformArmor(class_4587 poses, class_4597 buffers, class_1309 entity,
	                                  class_1304 slot, int light, class_572<?> model, CallbackInfo callback)
	{
		if (entity.method_6118(slot).method_7909() instanceof PArmorModelProvider provider)
			provider.setupPulseArmorAnimations(entity, entity.method_6118(slot), slot, model, class_310.method_1551().
					method_60646().method_60637(false));
		if (entity instanceof class_1657 player)
			PPlayerMeshDeformers.apply(player, model, class_310.method_1551().method_60646().
					method_60637(false));
	}
}
