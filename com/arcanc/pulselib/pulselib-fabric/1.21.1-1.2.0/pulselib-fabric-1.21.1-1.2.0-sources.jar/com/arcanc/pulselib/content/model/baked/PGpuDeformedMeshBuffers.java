/**
 * @author ArcAnc
 * Created at: 27.01.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.baked;

import com.arcanc.pulselib.content.model.PMeshPrimitive;
import com.arcanc.pulselib.content.model.deformer.PMeshTessellator;
import com.arcanc.pulselib.content.renderer.plan.PGeometryData;
import com.arcanc.pulselib.util.PRenderTypes;
import com.arcanc.pulselib.util.PResourceCache;
import com.mojang.blaze3d.vertex.*;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_1058;
import net.minecraft.class_287;
import net.minecraft.class_293;
import net.minecraft.class_9799;
import net.minecraft.class_9801;

/**
 * Caches subdivided source geometry used by GPU mesh deformation.
 */
public final class PGpuDeformedMeshBuffers
{

	private static final Map<PBakedMesh, Map<Integer, PGeometryData>> GEOMETRIES = new IdentityHashMap<>();

	private PGpuDeformedMeshBuffers()
	{
	}

	/**
	 * Returns the mesh geometry subdivided to the requested deformation level.
	 *
	 * @param mesh the baked mesh geometry and material
	 * @param subdivisionLevel the triangle subdivision level applied before deformation
	 * @return the mesh geometry subdivided to the requested deformation level
	 */
	public static PGeometryData resolve(PBakedMesh mesh, int subdivisionLevel)
	{
		if (subdivisionLevel < 0)
			throw new IllegalArgumentException("Subdivision level cannot be negative");
		if (subdivisionLevel == 0)
			return mesh.geometry();
		return GEOMETRIES.computeIfAbsent(mesh, ignored -> new HashMap<>()).computeIfAbsent(
				subdivisionLevel, level -> bake(mesh, PMeshTessellator.subdivide(mesh.source(), level)));
	}

	/**
	 * Removes cached GPU deformation geometry for the supplied mesh.
	 *
	 * @param mesh the baked mesh geometry and material
	 */
	public static void close(PBakedMesh mesh)
	{
		GEOMETRIES.remove(mesh);
	}

	/**
	 * Clears all cached GPU deformation geometry.
	 */
	public static void cleanup()
	{
		GEOMETRIES.clear();
	}

	private static PGeometryData bake(PBakedMesh baked, PMeshPrimitive mesh)
	{
		class_1058 sprite = PResourceCache.getTextureAtlas().method_4608(baked.textureLocation());
		try (class_9799 bytes = new class_9799(mesh.vertexCount() * PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL.method_1362()))
		{
			class_287 builder = sprite.method_45851().method_45816().method_12832().equals("missingno") ?
					new class_287(bytes, class_293.class_5596.field_27379, PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL) :
					new AtlasBufferBuilder(bytes, class_293.class_5596.field_27379, PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL, sprite);
			for (int vertex = 0; vertex < mesh.vertexCount(); vertex++)
				builder.method_22912(mesh.positions().get(vertex * 3), mesh.positions().get(vertex * 3 + 1), mesh.positions().get(vertex * 3 + 2)).
						method_22913(mesh.uvs().get(vertex * 2), mesh.uvs().get(vertex * 2 + 1)).
						method_22914(mesh.normals().get(vertex * 3), mesh.normals().get(vertex * 3 + 1), mesh.normals().get(vertex * 3 + 2));
			try (class_9801 data = builder.method_60800())
			{
				ByteBuffer indices = mesh.indices().duplicate();
				indices.clear();
				return new PGeometryData(data.method_60818(), indices,
						PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL.method_1362(), mesh.indicesCount(),
						mesh.glIndexType() == class_293.class_5595.field_27372.field_27374 ?
								PGeometryData.IndexType.UNSIGNED_SHORT : PGeometryData.IndexType.UNSIGNED_INT);
			}
		}
	}
}
