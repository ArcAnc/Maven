/**
 * @author ArcAnc
 * Created at: 21.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.textures;

import com.arcanc.pulselib.content.mixin.SpriteContentsAccessor;
import com.arcanc.pulselib.content.model.textures.atlas.PLibMetadata;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_7764;

/**
 * Caches texture-pixel analysis used to choose opaque, cutout or translucent rendering.
 */
public final class PTextureAlphaClassifier
{
	private static final Map<class_7764, PAlphaMode> CACHE = new WeakHashMap<>();

	private PTextureAlphaClassifier()
	{
	}

	/**
	 * Classifies the alpha values of the supplied sprite contents.
	 *
	 * @param contents the contents
	 * @return the alpha policy inferred from the sprite pixels
	 */
	public static synchronized PAlphaMode resolve(class_7764 contents)
	{
		return CACHE.computeIfAbsent(contents, PTextureAlphaClassifier :: classify);
	}

	/**
	 * Discards cached texture alpha classifications.
	 */
	public static synchronized void clear()
	{
		CACHE.clear();
	}

	private static PAlphaMode classify(class_7764 contents)
	{
		PAlphaMode configured = contents.method_52848().method_43041(PLibMetadata.TYPE).
				map(PLibMetadata :: alphaMode).
				orElse(PAlphaMode.AUTO);
		if (configured != PAlphaMode.AUTO)
			return configured;

		class_1011 image = ((SpriteContentsAccessor) contents).pulselib$getOriginalImage();
		boolean transparent = false;
		for (int y = 0; y < image.method_4323(); y++)
			for (int x = 0; x < image.method_4307(); x++)
			{
				int alpha = image.method_4315(x, y) >>> 24;
				if (alpha == 0)
					transparent = true;
				else if (alpha < 255)
					return PAlphaMode.TRANSLUCENT;
			}
		return transparent ? PAlphaMode.CUTOUT : PAlphaMode.OPAQUE;
	}
}
