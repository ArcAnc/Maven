/**
 * @author ArcAnc
 * Created at: 26.03.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.baked;


import net.minecraft.class_1058;
import net.minecraft.class_287;
import net.minecraft.class_293;
import net.minecraft.class_4588;
import net.minecraft.class_9799;

/**
 * Vertex buffer builder that remaps texture coordinates into one atlas sprite.
 */
public class AtlasBufferBuilder extends class_287
{
	private final class_1058 sprite;
	
	/**
	 * Creates a vertex builder whose local UVs are mapped into the selected atlas sprite.
	 *
	 * @param buffer the vertex or buffer output
	 * @param mode the rule used to combine the layer with the accumulated value
	 * @param format the vertex layout used to interpret vertex bytes
	 * @param sprite the sprite
	 */
	public AtlasBufferBuilder(class_9799 buffer, class_293.class_5596 mode, class_293 format, class_1058 sprite)
	{
		super(buffer, mode, format);
		this.sprite = sprite;
	}
	
	/**
	 * Maps local texture coordinates into the selected atlas sprite before writing the vertex.
	 *
	 * @param u the u
	 * @param v the v
	 * @return this builder
	 */
	@Override
	public class_4588 method_22913(float u, float v)
	{
		super.method_22913(this.sprite.method_4580(u), this.sprite.method_4570(v));
		return this;
	}
}
