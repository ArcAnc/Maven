/**
 * @author ArcAnc
 * Created at: 12.10.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.fabric;

import com.arcanc.pulselib.content.mixin.CameraAccessor;
import com.arcanc.pulselib.content.player.animation.firstPerson.PFirstPersonCameraSpace;
import com.arcanc.pulselib.platform.IPulseCameraService;
import net.minecraft.class_4184;

/**
 * Fabric camera rotation bridge that applies yaw, pitch and roll and refreshes orientation vectors.
 */
public final class FabricCameraService implements IPulseCameraService
{
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setRotation(class_4184 camera, float yaw, float pitch, float roll)
	{
		((CameraAccessor)camera).pulselib$setRotation(yaw, pitch);
		PFirstPersonCameraSpace.fromMinecraftAngles(yaw, pitch, roll, camera.method_23767());
		camera.method_19335().set(0f, 0f, -1f).rotate(camera.method_23767());
		camera.method_19336().set(0f, 1f, 0f).rotate(camera.method_23767());
		camera.method_35689().set(-1f, 0f, 0f).rotate(camera.method_23767());
	}
}
