/**
 * @author ArcAnc
 * Created at: 30.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation;

import net.minecraft.class_1657;

/**
 * Samples a player animation contribution weight for the current render frame.
 */
@FunctionalInterface
public interface PPlayerAnimationWeight
{
	/**
	 * Weight provider that always returns full contribution.
	 */
	PPlayerAnimationWeight FULL = (player, partialTick) -> 1.0f;

	/**
	 * Returns the contribution weight for the supplied player and interpolation fraction.
	 *
	 * @param player the player whose animation or presentation is being processed
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the contribution weight for the supplied player and interpolation fraction
	 */
	float weight(class_1657 player, float partialTick);
}
