/**
 * @author ArcAnc
 * Created at: 25.03.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.textures.atlas;


import com.arcanc.pulselib.util.PLibDatabase;
import com.arcanc.pulselib.util.PResourceCache;
import com.mojang.serialization.MapCodec;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_2960;
import net.minecraft.class_3270;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_7766;
import net.minecraft.class_7948;
import net.minecraft.class_7951;
import net.minecraft.class_8684;

/**
 * Atlas sprite source that discovers textures referenced by registered PulseLib models.
 */
public class RuntimeLoader implements class_7948
{
	/**
	 * Serialization codec for runtime loader.
	 */
	public static final MapCodec<RuntimeLoader> CODEC = MapCodec.unit(RuntimeLoader ::new);
	/**
	 * Registered sprite source type for runtime model texture discovery.
	 */
	public static final class_7951 TYPE = new class_7951(CODEC);
	
	/**
	 * Adds the texture resources required by registered models to the atlas output.
	 *
	 * @param resourceManager the resource manager used to locate source assets
	 * @param output the output
	 */
	@Override
	public void method_47673(class_3300 resourceManager, class_7949 output)
	{
		PResourceCache.invalidateTextureAtlas();
		List<class_3270<?>> metadataSections = new ArrayList<>(class_7766.field_45632);
		metadataSections.add(PLibMetadata.TYPE);
		class_8684 spriteResourceLoader = class_8684.create(metadataSections);
		
		Set<class_2960> textures = PResourceCache.getResourceCache().values().stream()
				.flatMap(resource -> resource.textures().values().stream())
				.collect(Collectors.toSet());
		textures.forEach(texture ->
		{
			class_2960 resourcelocation = field_42075.method_45112(texture);
			Optional<class_3298> optional = resourceManager.method_14486(resourcelocation);
			if (optional.isPresent())
			{
				class_3298 resource = optional.get();
				class_2960 sprite = PResourceCache.spriteId(texture);
				output.method_47670(sprite, loader -> spriteResourceLoader.loadSprite(sprite, resource));
			}
			else
				PLibDatabase.LOGGER.warn("Missing sprite: {}", resourcelocation);
		});
	}
	
	/**
	 * Returns the sprite source type registered for this runtime loader.
	 *
	 * @return the sprite source type registered for this runtime loader
	 */
	@Override
	public class_7951 method_47672()
	{
		return TYPE;
	}
}
