/**
 * @author ArcAnc
 * Created at: 30.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Exposes vanilla first-person arm rendering for animated held-arm presentation.
 */
@Mixin(class_759.class)
public interface ItemInHandRendererAccessor
{
	/**
	 * Invokes vanilla first-person arm rendering with the supplied hand-pass inputs.
	 *
	 * @param poseStack the current model-to-render pose stack
	 * @param buffer the vertex or buffer output
	 * @param packedLight the packed block and sky light coordinates
	 * @param equippedProgress the vanilla hand equip animation progress
	 * @param swingProgress the vanilla hand swing animation progress
	 * @param side the physical-side restriction of the plugin candidate
	 */
	@Invoker("renderPlayerArm")
	void pulselib$renderPlayerArm(class_4587 poseStack,
	                              class_4597 buffer,
	                              int packedLight,
	                              float equippedProgress,
	                              float swingProgress,
	                              class_1306 side);
}
