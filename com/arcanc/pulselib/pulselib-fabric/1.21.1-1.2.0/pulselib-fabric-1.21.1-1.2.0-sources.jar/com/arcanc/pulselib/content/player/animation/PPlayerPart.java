/**
 * @author ArcAnc
 * Created at: 30.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation;

import java.util.List;
import net.minecraft.class_591;
import net.minecraft.class_630;

/**
 * Player model parts addressable by animation bindings and deformation masks.
 */
public enum PPlayerPart
{
	/**
	 * Root transform affecting the entire player presentation.
	 */
	ROOT,
	/**
	 * Player head and its associated model geometry.
	 */
	HEAD,
	/**
	 * Player torso model part.
	 */
	BODY,
	/**
	 * Player right arm model part.
	 */
	RIGHT_ARM,
	/**
	 * Player left arm model part.
	 */
	LEFT_ARM,
	/**
	 * Player right leg model part.
	 */
	RIGHT_LEG,
	/**
	 * Player left leg model part.
	 */
	LEFT_LEG;

	/**
	 * Resolves this animation part to the corresponding vanilla model parts.
	 *
	 * @param model the model
	 * @return the vanilla model parts represented by this animation part
	 */
	public List<class_630> resolve(class_591<?> model)
	{
		return switch (this)
		{
			case ROOT -> List.of();
			case HEAD -> List.of(model.field_3398, model.field_3394);
			case BODY -> List.of(model.field_3391, model.field_3483);
			case RIGHT_ARM -> List.of(model.field_3401, model.field_3486);
			case LEFT_ARM -> List.of(model.field_27433, model.field_3484);
			case RIGHT_LEG -> List.of(model.field_3392, model.field_3479);
			case LEFT_LEG -> List.of(model.field_3397, model.field_3482);
		};
	}
}
