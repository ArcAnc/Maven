/**
 * @author ArcAnc
 * Created at: 23.09.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation;

import com.arcanc.pulselib.content.model.animation.PTransform;
import net.minecraft.class_2960;

/**
 * The resolved transform of one player-animation anchor.
 *
 * @param animation the namespaced resource or registry identifier
 * @param anchor the anchor
 * @param transform the transform
 * @param weight the contribution weight
 */
public record PPlayerAnimationAnchorPose(class_2960 animation,
                                         PPlayerAnimationAnchor anchor,
                                         PTransform transform,
                                         float weight)
{
}
