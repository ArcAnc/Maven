/**
 * @author ArcAnc
 * Created at: 13.10.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.renderer.PRenderQueue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.class_279;
import net.minecraft.class_310;
import net.minecraft.class_761;

/** Inserts OIT after the same vanilla transparency pass on both loaders. */
@Mixin (class_761.class)
public abstract class LevelRendererTransparencyMixin
{
	@Shadow
	private @Nullable class_279 transparencyChain;

	/**
	 * Composites PulseLib translucency together with vanilla Fabulous transparency targets.
	 *
	 * @param chain the chain
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param original the original implementation or unmodified value supplied by the render hook
	 */
	@WrapOperation (method = "renderLevel", at = @At (value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/PostChain;process(F)V"))
	private void pulselib$compositeFabulous(class_279 chain, float partialTick, Operation<Void> original)
	{
		original.call(chain, partialTick);
		if (chain == this.transparencyChain)
		{
			class_761 renderer = (class_761)(Object)this;
			PRenderQueue.compositeFabulousTranslucency(class_310.method_1551().method_1522(), List.of(
					renderer.method_29360(), renderer.method_29361(), renderer.method_29362(),
					renderer.method_29363(), renderer.method_29364()));
		}
	}
}
