/**
 * @author ArcAnc
 * Created at: 23.09.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation.firstPerson;

import com.arcanc.pulselib.content.player.animation.attachment.PPlayerAnimatedAttachments;
import com.arcanc.pulselib.content.player.animation.attachment.PPlayerAutomaticMeshAttachments;
import com.arcanc.pulselib.util.attachments.humanoid.PHumanoidAttachmentLayer;
import net.minecraft.class_1007;
import net.minecraft.class_1306;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_746;
import net.minecraft.class_897;

/**
 * PulseLib's first-person extra-geometry coordinator.  It has no mixin entry
 * point: the following integration stage supplies the native 1.21.1 callback.
 */
public final class PPlayerFirstPersonRenderer
{
	private PPlayerFirstPersonRenderer() {}

	/**
	 * Renders animated attachments and mesh extras using the sampled first-person presentation.
	 *
	 * @param player the player whose animation or presentation is being processed
	 * @param presentation the presentation
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	public static void renderExtras(class_746 player, PFirstPersonRenderPresentation presentation,
	                                class_4587 poseStack, class_4597 buffers, int packedLight, float partialTick)
	{
		PPlayerAutomaticMeshAttachments.renderFirstPerson(presentation.meshAttachments(), poseStack, packedLight);
		PPlayerAnimatedAttachments.renderFirstPerson(player, presentation, poseStack, buffers, packedLight, partialTick);
		renderPersistentAttachments(player, class_1306.field_6183, presentation.rightArm(), poseStack, packedLight, partialTick);
		renderPersistentAttachments(player, class_1306.field_6182, presentation.leftArm(), poseStack, packedLight, partialTick);
	}

	private static void renderPersistentAttachments(class_746 player, class_1306 arm, PFirstPersonArmPose pose,
	                                                class_4587 poseStack, int packedLight, float partialTick)
	{
		if (pose.mode() != PFirstPersonRenderMode.ANIMATED) return;
        class_897<?> renderer = class_310.method_1551().method_1561().method_3953(player);
        if (!(renderer instanceof class_1007 playerRenderer)) {
            return;
        }
        class_591<?> model = playerRenderer.method_4038();
		class_630 armPart = arm == class_1306.field_6183 ? model.field_3401 : model.field_27433;
		poseStack.method_22903();
		try
		{
			poseStack.method_34425(PVanillaFirstPersonArmResolver.resolveArmOrigin(arm, pose.transform()).matrix());
			PHumanoidAttachmentLayer.renderFirstPersonArm(poseStack, packedLight, player, arm, armPart, partialTick);
		}
		finally { poseStack.method_22909(); }
	}
}
