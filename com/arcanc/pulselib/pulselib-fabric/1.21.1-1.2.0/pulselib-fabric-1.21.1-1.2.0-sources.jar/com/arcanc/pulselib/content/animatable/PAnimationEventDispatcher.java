/**
 * @author ArcAnc
 * Created at: 27.05.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */
package com.arcanc.pulselib.content.animatable;

import com.arcanc.pulselib.content.model.animation.*;
import com.arcanc.pulselib.content.model.baked.PBakedModel;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;

/**
 * Routes animation events to side-appropriate handlers and resolves locator positions from the animated
 * pose.
 */
public final class PAnimationEventDispatcher
{
	private PAnimationEventDispatcher() { }

	/**
	 * Dispatches an animation event using the owner, controller and available pose information.
	 *
	 * @param <T> the animatable owner type
	 * @param animatable the owner whose animation state is being processed
	 * @param controller the controller supplying playback and persistent expression state
	 * @param event the typed animation event to dispatch
	 * @param model the baked model supplying indexed bones and animations; may be {@code null}
	 * @param controllers the animation controllers in pose composition order
	 */
	public static <T extends PAnimatable<T>> void dispatch(T animatable, PAnimationController<T> controller,
	                                                       PAnimationEvent<?> event, @Nullable PBakedModel model,
	                                                       Collection<PAnimationController<T>> controllers)
	{
		@Nullable PositionContext fallback = position(animatable);
		@Nullable class_1937 level = fallback == null ? null : fallback.level();
		if (!runsOn(event.type().side(), level))
			return;

		PAnimationEventContext context = new PAnimationEventContext(animatable, controller, model, controllers, level,
				locator -> positionFor(animatable, model, controllers, fallback, locator));
		execute(context, event);
	}
	
	/**
	 * Dispatches an animation event using the owner, controller and available pose information.
	 *
	 * @param <T> the animatable owner type
	 * @param animatable the owner whose animation state is being processed
	 * @param controller the controller supplying playback and persistent expression state
	 * @param event the typed animation event to dispatch
	 */
	public static <T extends PAnimatable<T>> void dispatch(T animatable, PAnimationController<T> controller,
	                                                       PAnimationEvent<?> event)
	{
		dispatch(animatable, controller, event, null, List.of(controller));
	}

	private static boolean runsOn(PEventSide side, @Nullable class_1937 level)
	{
		boolean client = level == null || level.method_8608();
		return switch (side)
		{
			case CLIENT, PRESENTATION_ONLY -> client;
			case SERVER -> !client;
			case BOTH -> true;
		};
	}

	@SuppressWarnings("unchecked")
	private static <T> void execute(PAnimationEventContext context, PAnimationEvent<?> event)
	{
		PAnimationEvent<T> typed = (PAnimationEvent<T>)event;
		PAnimationEventType<T> type = typed.type();
		type.execute(context, typed.data());
	}

	private static <T extends PAnimatable<T>> @Nullable PAnimationEventContext.PAnimationEventDispatcherBridge.Position positionFor(
			T animatable, @Nullable PBakedModel model, Collection<PAnimationController<T>> controllers,
			@Nullable PositionContext fallback, String locator)
	{
		if (fallback == null)
			return null;
		PositionContext position = fallback;
		if (model != null && !locator.isBlank())
			position = resolveLocatorPosition(animatable, locator, model, controllers, position);
		return new PAnimationEventContext.PAnimationEventDispatcherBridge.Position(position.level(), position.x(), position.y(), position.z());
	}

	private static <T extends PAnimatable<T>> PositionContext resolveLocatorPosition(T animatable, String locator,
			PBakedModel model, Collection<PAnimationController<T>> controllers, PositionContext fallback)
	{
		Vector3f localPosition = new Vector3f();
		if (!findBonePosition(model, controllers, locator, localPosition))
			return fallback;
		if (animatable instanceof class_1297 entity)
		{
			float scale = entity instanceof class_1309 living ? living.method_55693() : 1f;
			float yRot = entity instanceof class_1309 living ? living.field_6283 : entity.method_36454();
			localPosition.mul(scale).rotateY((float)Math.toRadians(180f - yRot));
			return new PositionContext(fallback.level(), entity.method_23317() + localPosition.x(), entity.method_23318() + localPosition.y(),
					entity.method_23321() + localPosition.z());
		}
		if (animatable instanceof class_2586 blockEntity)
		{
			class_2338 pos = blockEntity.method_11016();
			rotateForBlockState(localPosition, blockEntity.method_11010());
			return new PositionContext(fallback.level(), pos.method_10263() + .5 + localPosition.x(), pos.method_10264() + .5 + localPosition.y(),
					pos.method_10260() + .5 + localPosition.z());
		}
		return fallback;
	}

	private static void rotateForBlockState(Vector3f localPosition, class_2680 blockState)
	{
		class_2350 direction = class_2350.field_11043;
		if (blockState.method_28498(class_2741.field_12481)) direction = blockState.method_11654(class_2741.field_12481);
		if (blockState.method_28498(class_2741.field_12525)) direction = blockState.method_11654(class_2741.field_12525);
		if (direction.method_10166() == class_2350.class_2351.field_11051) direction = direction.method_10153();
		if (direction.method_10166().method_10179()) localPosition.rotateY((float)Math.toRadians(direction.method_10144()));
		else localPosition.rotateX((float)Math.toRadians(90f * direction.method_10163().method_10264()));
	}

	private static <T extends PAnimatable<T>> boolean findBonePosition(PBakedModel model,
			Collection<PAnimationController<T>> controllers, String boneName, Vector3f result)
	{
		int boneIndex = model.boneIndex(boneName);
		if (boneIndex < 0) return false;
		PPose localPose = model.evaluate(controllers, Map.of(), 1f);
		PModelPose modelPose = new PModelPose(model.boneCount());
		modelPose.update(model, localPose);
		result.set(modelPose.transform(boneIndex).translation());
		return true;
	}

	private static @Nullable PositionContext position(PAnimatable<?> animatable)
	{
		if (animatable instanceof class_1297 entity)
			return new PositionContext(entity.method_37908(), entity.method_23317(), entity.method_23318(), entity.method_23321());
		if (animatable instanceof class_2586 blockEntity && blockEntity.method_10997() != null)
		{
			class_2338 pos = blockEntity.method_11016();
			return new PositionContext(blockEntity.method_10997(), pos.method_10263() + .5, pos.method_10264() + .5, pos.method_10260() + .5);
		}
		return null;
	}

	/**
	 * Model and controller inputs used to resolve an event locator into world space.
	 *
	 * @param level the level
	 * @param x the x component or coordinate
	 * @param y the y component or coordinate
	 * @param z the z component or coordinate
	 */
	private record PositionContext(class_1937 level, double x, double y, double z) { }
}
