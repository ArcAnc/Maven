/**
 * @author ArcAnc
 * Created at: 13.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.renderer.legacy;

import com.arcanc.pulselib.content.model.PMeshPrimitive;
import com.arcanc.pulselib.content.renderer.plan.PGeometryData;
import java.nio.ByteBuffer;
import net.minecraft.class_293;
import net.minecraft.class_9801;

/**
 * Captures baked mesh bytes into renderer-independent geometry data.
 */
public final class GlGeometryDataFactory
{
	private GlGeometryDataFactory()
	{
	}

	/**
	 * Copies vertex and index data from a baked mesh into portable geometry storage.
	 *
	 * @param meshData the mesh data
	 * @param mesh the mesh
	 * @param vertexStride the number of bytes occupied by one vertex
	 * @return the immutable indexed mesh geometry
	 */
	public static PGeometryData capture(class_9801 meshData, PMeshPrimitive mesh, int vertexStride)
	{
		ByteBuffer vertices = meshData.method_60818().duplicate();
		ByteBuffer indices = mesh.indices().duplicate();
		indices.clear();
		return new PGeometryData(vertices, indices, vertexStride, mesh.indicesCount(),
				mesh.glIndexType() == class_293.class_5595.field_27372.field_27374 ?
						PGeometryData.IndexType.UNSIGNED_SHORT : PGeometryData.IndexType.UNSIGNED_INT);
	}
}
