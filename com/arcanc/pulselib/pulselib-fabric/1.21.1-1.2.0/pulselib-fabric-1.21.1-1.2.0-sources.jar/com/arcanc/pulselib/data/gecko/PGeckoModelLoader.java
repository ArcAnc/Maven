/**
 * @author ArcAnc
 * Created at: 24.05.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.data.gecko;

import com.arcanc.pulselib.content.model.PModel;
import com.arcanc.pulselib.data.PAnimationSidecarParser;
import com.arcanc.pulselib.data.PLoadedModel;
import com.arcanc.pulselib.data.PModelLoader;
import com.arcanc.pulselib.util.PLibDatabase;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_4587;

/**
 * Loads Gecko models and their animation sidecars.
 */
public class PGeckoModelLoader implements PModelLoader
{
	/**
	 * Shared instance of this stateless implementation.
	 */
	public static final PGeckoModelLoader INSTANCE = new PGeckoModelLoader();

	private static final class_2960 ID = PLibDatabase.rl("gecko");

	private static final String MODEL_ROOT = "geckolib/models";
	private static final String ANIMATION_ROOT = "geckolib/animations";
	private static final String MODEL_EXTENSION = ".geo.json";
	private static final String ANIMATION_EXTENSION = ".animation.json";
	private static final String EVENTS_EXTENSION = ".events.json";
	private static final String ANIMATION_EVENTS_EXTENSION = ".animation_events.json";
	private static final String JSON_EXTENSION = ".json";

	private PGeckoModelLoader()
	{
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public class_2960 id()
	{
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void applyItemTransform(class_4587 poseStack)
	{
		poseStack.method_46416(0.5f, 0.51f, 0.5f);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<class_2960> modelResourceCandidates(class_2960 modelId)
	{
		return List.of(modelId.method_45138(MODEL_ROOT + "/").method_48331(MODEL_EXTENSION));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public CompletableFuture<PLoadedModel> loadModel(Executor backgroundExecutor,
	                                                 class_3300 resourceManager,
	                                                 class_2960 modelId)
	{
		return CompletableFuture.supplyAsync(() ->
		{
			class_2960 source = modelResourceCandidates(modelId).stream()
					.filter(candidate -> resourceManager.method_14486(candidate).isPresent())
					.findFirst()
					.orElseThrow(() -> new IllegalStateException(
							"Registered model was not loaded: " + modelId + "; checked resources: "
									+ modelResourceCandidates(modelId)));
			try
			{
				PModel model = PGeckoModelParser.parseModel(resourceManager.getResourceOrThrow(source).method_14482());
				loadAnimations(resourceManager, source, model);
				return new PLoadedModel(modelId, source, model);
			}
			catch (IOException exception)
			{
				throw new RuntimeException("Can't load Gecko model " + source + " for " + modelId, exception);
			}
		}, backgroundExecutor);
	}

	private void loadAnimations(class_3300 resourceManager, class_2960 modelResource, PModel model) throws IOException
	{
		Optional<class_2960> animationResource = animationCandidates(modelResource).stream()
				.filter(resource -> resourceManager.method_14486(resource).isPresent())
				.findFirst();

		if (animationResource.isEmpty())
			return;

		model.animations.putAll(PGeckoModelParser.parseAnimations(
				resourceManager.getResourceOrThrow(animationResource.get()).method_14482(), model));
		loadAnimationSidecar(resourceManager, animationResource.get(), model);
	}

	private void loadAnimationSidecar(class_3300 resourceManager,
	                                  class_2960 animationResource,
	                                  PModel model) throws IOException
	{
		Optional<class_2960> sidecarResource = sidecarCandidates(animationResource).stream()
				.filter(resource -> resourceManager.method_14486(resource).isPresent())
				.findFirst();
		if (sidecarResource.isEmpty())
			return;

		PAnimationSidecarParser.mergeSidecar(
				PAnimationSidecarParser.parseJson(resourceManager.getResourceOrThrow(sidecarResource.get()).method_14482()),
				model.animations);
	}

	private List<class_2960> animationCandidates(class_2960 modelResource)
	{
		String modelName = modelName(modelResource);
		String fileName = modelName.substring(modelName.lastIndexOf('/') + 1);

		List<class_2960> candidates = new ArrayList<>();
		candidates.add(modelResource.method_45136(ANIMATION_ROOT + "/" + fileName + ANIMATION_EXTENSION));
		candidates.add(modelResource.method_45136(ANIMATION_ROOT + "/" + fileName + JSON_EXTENSION));
		candidates.add(modelResource.method_45136(ANIMATION_ROOT + "/" + modelName + ANIMATION_EXTENSION));
		candidates.add(modelResource.method_45136(ANIMATION_ROOT + "/" + modelName + JSON_EXTENSION));
		return candidates;
	}

	private List<class_2960> sidecarCandidates(class_2960 animationResource)
	{
		String path = animationResource.method_12832();
		String base = path.endsWith(ANIMATION_EXTENSION)
				? path.substring(0, path.length() - ANIMATION_EXTENSION.length())
				: path.substring(0, path.length() - JSON_EXTENSION.length());
		String fileName = base.substring(base.lastIndexOf('/') + 1);
		String root = base.substring(0, base.lastIndexOf('/'));

		List<class_2960> candidates = new ArrayList<>();
		candidates.add(animationResource.method_45136(base + EVENTS_EXTENSION));
		candidates.add(animationResource.method_45136(base + ANIMATION_EVENTS_EXTENSION));
		candidates.add(animationResource.method_45136(root + "/events/" + fileName + EVENTS_EXTENSION));
		return candidates;
	}

	private static String modelName(class_2960 modelResource)
	{
		String path = modelResource.method_12832();
		String modelName = path.substring(MODEL_ROOT.length() + 1);
		return modelName.substring(0, modelName.length() - MODEL_EXTENSION.length());
	}
}
