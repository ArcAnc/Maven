/**
 * @author ArcAnc
 * Created at: 04.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.util.attachments;


import com.arcanc.pulselib.content.animatable.PAnimationController;
import com.arcanc.pulselib.content.model.baked.PBakedBone;
import com.arcanc.pulselib.content.model.baked.PBakedModel;
import com.arcanc.pulselib.content.model.baked.PMeshRenderContext;
import com.arcanc.pulselib.util.PRenderTypes;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.Collection;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_7833;

/**
 * Living entity render layer that submits item-specific and global attachment definitions.
 *
 * @param <T> the entity type rendered or animated by this contract
 * @param <M> the entity type rendered or animated by this contract
 */
public class PLivingAttachmentLayer<T extends class_1309, M extends class_583<T>> extends class_3887<T, M>
{
	/**
	 * Equipment slots inspected when selecting item-specific attachments.
	 */
	protected static final List<class_1304> EQUIPMENT_SLOTS = List.of(
			class_1304.field_6169,
			class_1304.field_6174,
			class_1304.field_6172,
			class_1304.field_6166,
			class_1304.field_48824,
			class_1304.field_6173,
			class_1304.field_6171);
	
	/**
	 * Attaches living attachment rendering to the supplied vanilla renderer.
	 *
	 * @param parent the parent
	 */
	public PLivingAttachmentLayer(class_3883<T, M> parent)
	{
		super(parent);
	}
	
	/**
	 * Resolves equipped and global living attachments and submits their bound model bones.
	 *
	 * @param poseStack the current model-to-render pose stack
	 * @param buffer the vertex or buffer output
	 * @param light the packed block and sky light coordinates
	 * @param entity the entity being animated or rendered
	 * @param limbSwing the entity limb animation position
	 * @param limbSwingAmount the entity limb animation amplitude
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param ageInTicks the entity age used by vanilla render animation
	 * @param netHeadYaw the head yaw relative to the body in degrees
	 * @param headPitch the head pitch in degrees
	 */
	@Override
	public void render(class_4587 poseStack,
	                   class_4597 buffer,
	                   int light,
	                   T entity,
	                   float limbSwing,
	                   float limbSwingAmount,
	                   float partialTick,
	                   float ageInTicks,
	                   float netHeadYaw,
	                   float headPitch)
	{
		for (class_1304 slot : EQUIPMENT_SLOTS)
		{
			class_1799 stack = entity.method_6118(slot);
			for (PLivingAttachmentDefinition definition : PLivingAttachments.get(stack, slot, entity))
				renderDefinition(poseStack, light, partialTick, entity, stack, definition,
						binding -> PAttachmentAnchorResolvers.resolve(entity, this.method_17165(), binding.anchor()));
		}
		
		for (PLivingAttachmentDefinition definition : PLivingAttachments.getGlobal(entity))
			renderDefinition(poseStack, light, partialTick, entity, class_1799.field_8037, definition,
					binding -> PAttachmentAnchorResolvers.resolve(entity, this.method_17165(), binding.anchor()));
	}
	
	/**
	 * Renders eligible attachments at the supplied first-person model anchor.
	 *
	 * @param poseStack the current model-to-render pose stack
	 * @param light the packed block and sky light coordinates
	 * @param entity the entity being animated or rendered
	 * @param targetAnchor the model anchor at which attachments are rendered
	 * @param anchorPart the vanilla model part representing the attachment anchor
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected static void renderFirstPersonAnchor(class_4587 poseStack,
	                                              int light,
	                                              class_1309 entity,
	                                              PAttachmentAnchor targetAnchor,
	                                              class_630 anchorPart,
	                                              float partialTick)
	{
		for (class_1304 slot : EQUIPMENT_SLOTS)
		{
			class_1799 stack = entity.method_6118(slot);
			for (PLivingAttachmentDefinition definition : PLivingAttachments.get(stack, slot, entity))
				renderDefinition(poseStack, light, partialTick, entity, stack, definition,
						binding -> binding.anchor().equals(targetAnchor) ? anchorPart : null);
		}

		for (PLivingAttachmentDefinition definition : PLivingAttachments.getGlobal(entity))
			renderDefinition(poseStack, light, partialTick, entity, class_1799.field_8037, definition,
					binding -> binding.anchor().equals(targetAnchor) ? anchorPart : null);
	}
	
	private static void renderDefinition(
			class_4587 poseStack,
			int light,
			float partialTick,
			class_1309 entity,
			class_1799 stack,
			PLivingAttachmentDefinition definition,
			AttachmentPartResolver partResolver)
	{
		PBakedModel model = definition.model().getModel();
		if (model == null)
			return;
		
		Collection<PAnimationController<?>> controllers = definition.animationControllers(entity, stack, model, partialTick);
		
		for (PAttachmentBinding binding : definition.bindings())
		{
			class_630 vanillaPart = partResolver.resolve(binding);
			if (vanillaPart == null)
				continue;
			
			PBakedBone bone = findBone(model.bones(), binding.bone());
			if (bone == null)
				continue;
			
			poseStack.method_22903();
			vanillaPart.method_22703(poseStack);
			poseStack.method_22907(class_7833.field_40718.rotationDegrees(180));
			PTransform transform = binding.transform();
			Vector3f offset = transform.offset();
			Quaternionf rotation = transform.rotation();
			Vector3f scale = transform.scale();
			poseStack.method_46416(offset.x(), offset.y(), offset.z());
			poseStack.method_22907(rotation);
			poseStack.method_22905(scale.x(), scale.y(), scale.z());
			poseStack.method_46416(-bone.basePosition().x(), -bone.basePosition().y(), -bone.basePosition().z());
			
			drawBone(poseStack, definition, bone, entity, stack, controllers, light, partialTick);
			
			poseStack.method_22909();
		}
	}
	
	private static void drawBone(class_4587 poseStack,
	                             PLivingAttachmentDefinition definition,
	                             PBakedBone bone,
	                             class_1309 entity,
	                             class_1799 stack,
	                             Collection<PAnimationController<?>> controllers,
	                             int light,
	                             float partialTick)
	{
		drawBoneUnchecked(poseStack, definition, bone, entity, stack, controllers, light, partialTick);
	}
	
	@SuppressWarnings({"rawtypes", "unchecked"})
	private static void drawBoneUnchecked(class_4587 poseStack,
	                                      PLivingAttachmentDefinition definition,
	                                      PBakedBone bone,
	                                      class_1309 entity,
	                                      class_1799 stack,
	                                      Collection<PAnimationController<?>> controllers,
	                                      int light,
	                                      float partialTick)
	{
		PMeshRenderContext context = new PMeshRenderContext(
				PRenderTypes.RenderTypeProvider :: trianglesImmediate,
				-1,
				light,
				class_4608.field_21444);
		
		bone.instantDraw(
				poseStack,
				definition.model(),
				(Collection) controllers,
				(bakedBone, mesh, inherited) ->
						definition.renderResolver().resolve(entity, stack, bakedBone, mesh, inherited, partialTick),
				context,
				partialTick);
	}
	
	private static @Nullable PBakedBone findBone(List<PBakedBone> bones, String name)
	{
		for (PBakedBone bone : bones)
		{
			if (bone.name().equals(name))
				return bone;
			
			PBakedBone child = findBone(bone.children(), name);
			if (child != null)
				return child;
		}
		
		return null;
	}
	
	/**
	 * Resolves the vanilla model part followed by an attachment binding.
	 */
	@FunctionalInterface
	private interface AttachmentPartResolver
	{
		/**
		 * Returns the model part selected by the supplied attachment binding.
		 *
		 * @param binding the binding
		 * @return the model part selected by the supplied attachment binding, or {@code null} when the requested value is unavailable
		 */
		@Nullable class_630 resolve(PAttachmentBinding binding);
	}
}
