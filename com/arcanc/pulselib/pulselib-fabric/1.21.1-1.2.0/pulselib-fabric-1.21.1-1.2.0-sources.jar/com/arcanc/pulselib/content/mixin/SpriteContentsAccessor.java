/**
 * @author ArcAnc
 * Created at: 12.10.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import net.minecraft.class_1011;
import net.minecraft.class_7764;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes original sprite pixels for texture alpha classification.
 */
@Mixin (class_7764.class)
public interface SpriteContentsAccessor
{
	/**
	 * Returns the original sprite image used for alpha classification.
	 *
	 * @return the original sprite image used for alpha classification
	 */
	@Accessor ("originalImage")
	class_1011 pulselib$getOriginalImage();
}
