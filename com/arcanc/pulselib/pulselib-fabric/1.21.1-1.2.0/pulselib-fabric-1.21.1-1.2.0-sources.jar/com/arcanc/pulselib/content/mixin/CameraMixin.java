/**
 * @author ArcAnc
 * Created at: 30.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.animatable.PAnimationCameraShake;
import com.arcanc.pulselib.content.player.animation.PPlayerAnimations;
import com.arcanc.pulselib.content.player.animation.firstPerson.PFirstPersonCameraSpace;
import com.arcanc.pulselib.platform.PulseClientServices;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_746;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies animated player camera motion and event-driven camera shake after vanilla camera setup.
 */
@Mixin(class_4184.class)
public abstract class CameraMixin
{
	/**
	 * Updates the vanilla camera position in world coordinates.
	 *
	 * @param pos the pos
	 */
	@Shadow
	protected abstract void setPosition(class_243 pos);

	@Unique
	private void pulselib$setRotation(float yaw, float pitch, float roll)
	{
		PulseClientServices.CAMERA.setRotation((class_4184)(Object)this, yaw, pitch, roll);
	}

	/**
	 * Adds local-player animation camera offsets, rotation and camera shake after vanilla setup.
	 *
	 * @param level the level
	 * @param entity the entity being animated or rendered
	 * @param detached the detached
	 * @param thirdPersonReverse the third person reverse
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param ci the Mixin callback for the intercepted method
	 */
	@Inject(method = "setup", at = @At("TAIL"))
	private void pulselib$followAnimatedHead(class_1922 level,
	                                          class_1297 entity,
	                                          boolean detached,
	                                          boolean thirdPersonReverse,
	                                          float partialTick,
	                                          CallbackInfo ci)
	{
		if (detached || entity != class_310.method_1551().field_1724 || !(entity instanceof class_746 player))
			return;

		PPlayerAnimations.PPlayerCameraPose pose = PPlayerAnimations.cameraPose(player, partialTick);
		float shake = PAnimationCameraShake.sample(partialTick);
		if (pose == null && shake == 0.0f)
			return;
		if (pose == null)
		{
			class_4184 camera = (class_4184)(Object)this;
			this.pulselib$setRotation(camera.method_19330() + shake, camera.method_19329() + shake * 0.5f, 0.0f);
			return;
		}

		class_4184 camera = (class_4184)(Object)this;
		Quaternionf bodyRotation = new Quaternionf().rotationY((float)Math.toRadians(180.0f - class_3532.method_17821(partialTick, player.field_6220, player.field_6283)));

		Vector3f positionOffset = PFirstPersonCameraSpace.toMinecraftOffset(pose.positionOffset(player.method_5751())).rotate(bodyRotation);
		this.setPosition(camera.method_19326().method_1031(positionOffset.x, positionOffset.y, positionOffset.z));

		if (!pose.hasRotation())
			return;
		Quaternionf modelRotation = PFirstPersonCameraSpace.toMinecraftRotation(pose.rotation());
		Quaternionf worldRotation = new Quaternionf(bodyRotation).
				mul(modelRotation).
				mul(new Quaternionf(bodyRotation).invert());
		Quaternionf cameraRotation = worldRotation.mul(new Quaternionf(camera.method_23767()));
		Vector3f euler = cameraRotation.getEulerAnglesYXZ(new Vector3f());
		this.pulselib$setRotation(
				180.0f - (float)Math.toDegrees(euler.y) + shake,
				-(float)Math.toDegrees(euler.x) + shake * 0.5f,
				-(float)Math.toDegrees(euler.z));
	}
}
