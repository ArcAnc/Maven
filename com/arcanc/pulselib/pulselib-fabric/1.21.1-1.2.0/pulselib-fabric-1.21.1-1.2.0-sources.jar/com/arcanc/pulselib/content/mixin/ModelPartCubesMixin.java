/**
 * @author ArcAnc
 * Created at: 08.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.player.deformer.PModelPartCubes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import net.minecraft.class_630;

/**
 * Exposes model-part cubes for configuring player mesh deformation.
 */
@Mixin(class_630.class)
public class ModelPartCubesMixin implements PModelPartCubes
{
	@Shadow @Final
	private List<class_630.class_628> cubes;

	/**
	 * Returns the vanilla model part's cube list.
	 *
	 * @return the vanilla model part's cube list
	 */
	@Override
	public List<class_630.class_628> pulselib$cubes()
	{
		return this.cubes;
	}
}
