/**
 * @author ArcAnc
 * Created at: 30.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation;

import com.arcanc.pulselib.content.animatable.AnimManagerKey;
import com.arcanc.pulselib.content.animatable.PAnimatable;
import com.arcanc.pulselib.content.animatable.PAnimationController;
import com.arcanc.pulselib.content.animatable.PAnimationManager;
import com.arcanc.pulselib.content.animatable.instance.InstanceAnimationManager;
import com.arcanc.pulselib.content.model.animation.PAnimationEvaluationContext;
import com.arcanc.pulselib.content.model.animation.PAnimationPoseResolver;
import com.arcanc.pulselib.content.model.animation.PTransitionInterruptionPolicy;
import com.arcanc.pulselib.content.model.baked.PBakedModel;
import com.arcanc.pulselib.data.gecko.MolangParser;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_3532;

/**
 * Per-player playback, activation crossfades and sampled pose state for one animation definition.
 */
public final class PPlayerAnimationInstance implements PAnimatable<PPlayerAnimationInstance>
{
	private class_1657 player;
	private final class_2960 id;
	private final PPlayerAnimationDefinition definition;
	private final PAnimationManager<PPlayerAnimationInstance> animationManager;
	private boolean targetActive;
	private float activation;
	private float previousActivation;
	private float transitionStart;
	private float transitionTarget;
	private float transitionElapsed;
	private boolean firstPersonTargetActive;
	private float firstPersonActivation;
	private float previousFirstPersonActivation;
	private float firstPersonTransitionStart;
	private float firstPersonTransitionTarget;
	private float firstPersonTransitionElapsed;
	private float firstPersonTransitionDuration;
	private @Nullable PPlayerAnimationFrame cachedFrame;
	private int cachedFramePartialTickBits;

	/**
	 * Creates independent playback and activation-transition state for one player animation.
	 *
	 * @param player the player whose animation or presentation is being processed
	 * @param id the namespaced resource or registration identifier
	 * @param definition the immutable configuration to register or evaluate
	 */
	PPlayerAnimationInstance(class_1657 player, class_2960 id, PPlayerAnimationDefinition definition)
	{
		this.player = Objects.requireNonNull(player);
		this.id = Objects.requireNonNull(id);
		this.definition = Objects.requireNonNull(definition);
		long key = Objects.hash(player.method_5667(), id);
		this.animationManager = new InstanceAnimationManager<>(this, new AnimManagerKey(key));
	}

	/**
	 * Returns the player whose animation or presentation is being processed.
	 *
	 * @return the player whose animation or presentation is being processed
	 */
	public class_1657 player()
	{
		return this.player;
	}

	/**
	 * Replaces the current player reference while retaining this instance's animation state.
	 *
	 * @param player the player whose animation or presentation is being processed
	 */
	void updatePlayer(class_1657 player)
	{
		this.player = Objects.requireNonNull(player);
	}

	/**
	 * Returns the namespaced resource or registration identifier.
	 *
	 * @return the namespaced resource or registration identifier
	 */
	public class_2960 id()
	{
		return this.id;
	}

	/**
	 * Returns the immutable configuration to register or evaluate.
	 *
	 * @return the immutable configuration to register or evaluate
	 */
	public PPlayerAnimationDefinition definition()
	{
		return this.definition;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PAnimationManager<PPlayerAnimationInstance> getAnimationManager(AnimManagerKey key)
	{
		return this.animationManager;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void registerAnimationControllers(PAnimationManager.PAnimationRegistrar<PPlayerAnimationInstance> registrar)
	{
		this.definition.registerControllers(registrar);
	}

	/**
	 * Returns the named controller belonging to this animation instance.
	 *
	 * @param controllerName the registered controller name
	 * @return the named controller belonging to this animation instance, or {@code null} when the requested value is unavailable
	 */
	@Nullable PAnimationController<PPlayerAnimationInstance> controller(String controllerName)
	{
		return this.animationManager.getControllers().get(controllerName);
	}

	/**
	 * Stops all controllers owned by this player animation instance.
	 */
	void stopAllControllers()
	{
		this.animationManager.getControllers().values().forEach(PAnimationController :: stop);
	}

	/**
	 * Aligns compatible cyclic playback with other instances in the synchronization group.
	 *
	 * @param instances the instances
	 */
	static void synchronize(List<PPlayerAnimationInstance> instances)
	{
		PPlayerAnimationInstance leader = instances.getFirst();
		PBakedModel leaderModel = leader.definition.modelData().getModel();
		if (leaderModel == null)
			return;
		for (Map.Entry<String, PAnimationController<PPlayerAnimationInstance>> entry : leader.animationManager.getControllers().entrySet())
		{
			float phase = entry.getValue().cyclePhase(leaderModel);
			if (Float.isNaN(phase))
				continue;
			for (int index = 1; index < instances.size(); index++)
			{
				PPlayerAnimationInstance follower = instances.get(index);
				PBakedModel followerModel = follower.definition.modelData().getModel();
				PAnimationController<PPlayerAnimationInstance> controller = follower.animationManager.getControllers().get(entry.getKey());
				if (followerModel != null && controller != null)
					controller.syncCycle(followerModel, phase);
			}
		}
	}

	/**
	 * Advances controller playback and activation transitions for the current player tick.
	 *
	 * @param shouldApply the should apply
	 */
	void tick(boolean shouldApply)
	{
		this.cachedFrame = null;
		PBakedModel model = this.definition.modelData().getModel();
		if (model == null)
			return;

		this.animationManager.bindModel(model);
		updateActivation(shouldApply);
		updateFirstPersonActivation(shouldApply && hasActiveController());
		if (shouldApply || this.activation > 0.0f)
			this.animationManager.tick();
	}

	/**
	 * Returns whether the instance can contribute to third-person player animation.
	 *
	 * @return whether the instance can contribute to third-person player animation
	 */
	boolean isContributing()
	{
		return this.activation > 0.0f || this.previousActivation > 0.0f || this.targetActive;
	}

	/**
	 * Samples the third-person activation crossfade weight.
	 *
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the interpolated third-person activation weight
	 */
	float activationWeight(float partialTick)
	{
		return class_3532.method_16439(partialTick, this.previousActivation, this.activation);
	}

	/**
	 * Returns whether the instance can contribute to first-person presentation.
	 *
	 * @return whether the instance can contribute to first-person presentation
	 */
	boolean isFirstPersonContributing()
	{
		return this.firstPersonActivation > 0.0f || this.previousFirstPersonActivation > 0.0f || this.firstPersonTargetActive;
	}

	/**
	 * Samples the first-person activation crossfade weight.
	 *
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the interpolated first-person activation weight
	 */
	float firstPersonActivationWeight(float partialTick)
	{
		return class_3532.method_16439(partialTick, this.previousFirstPersonActivation, this.firstPersonActivation);
	}

	/**
	 * Returns the named controller's interpolated animation time in seconds.
	 *
	 * @param controllerName the registered controller name
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the named controller's interpolated animation time in seconds
	 */
	float controllerAnimationTime(String controllerName, float partialTick)
	{
		PAnimationController<PPlayerAnimationInstance> controller = controller(controllerName);
		return controller == null ? 0.0f : controller.getInterpolatedTime(partialTick) / 20.0f;
	}

	private boolean hasActiveController()
	{
		return this.animationManager.getControllers().values().stream().anyMatch(controller ->
				controller.isPlaying() || controller.isPaused());
	}

	private void updateActivation(boolean shouldApply)
	{
		this.previousActivation = this.activation;
		if (shouldApply != this.targetActive)
		{
			if (this.transitionElapsed < this.definition.crossfadeDuration() &&
					this.definition.transitionInterruptionPolicy() == PTransitionInterruptionPolicy.COMPLETE_CURRENT)
			{
				// The current fade is allowed to finish; the new request is sampled next tick.
			}
			else
			{
			this.transitionStart = this.definition.transitionInterruptionPolicy() == PTransitionInterruptionPolicy.RESTART ?
						(this.targetActive ? 1.0f : 0.0f) : this.activation;
				this.transitionTarget = shouldApply ? 1.0f : 0.0f;
				this.transitionElapsed = 0.0f;
				this.targetActive = shouldApply;
			}
		}
		float duration = this.definition.crossfadeDuration();
		if (duration <= 0.0f)
		{
			this.activation = this.targetActive ? 1.0f : 0.0f;
			return;
		}
		this.transitionElapsed = Math.min(this.transitionElapsed + 1.0f, duration);
		float alpha = this.definition.crossfadeEasing().transform(this.transitionElapsed / duration);
		this.activation = class_3532.method_16439(alpha, this.transitionStart, this.transitionTarget);
	}

	private void updateFirstPersonActivation(boolean shouldApply)
	{
		var settings = this.definition.firstPersonSettings();
		this.previousFirstPersonActivation = this.firstPersonActivation;
		if (!settings.enabled())
		{
			this.firstPersonTargetActive = false;
			this.firstPersonActivation = 0.0f;
			return;
		}
		if (shouldApply != this.firstPersonTargetActive)
		{
			if (this.firstPersonTransitionElapsed < this.firstPersonTransitionDuration &&
					this.definition.transitionInterruptionPolicy() == PTransitionInterruptionPolicy.COMPLETE_CURRENT)
				return;
			this.firstPersonTransitionStart = this.definition.transitionInterruptionPolicy() == PTransitionInterruptionPolicy.RESTART ?
					(this.firstPersonTargetActive ? 1.0f : 0.0f) : this.firstPersonActivation;
			this.firstPersonTransitionTarget = shouldApply ? 1.0f : 0.0f;
			this.firstPersonTransitionDuration = shouldApply ? settings.transitionIn() : settings.transitionOut();
			this.firstPersonTransitionElapsed = 0.0f;
			this.firstPersonTargetActive = shouldApply;
		}
		if (this.firstPersonTransitionDuration <= 0.0f)
		{
			this.firstPersonActivation = this.firstPersonTargetActive ? 1.0f : 0.0f;
			return;
		}
		this.firstPersonTransitionElapsed = Math.min(this.firstPersonTransitionElapsed + 1.0f, this.firstPersonTransitionDuration);
		float alpha = this.definition.crossfadeEasing().transform(this.firstPersonTransitionElapsed / this.firstPersonTransitionDuration);
		this.firstPersonActivation = class_3532.method_16439(alpha, this.firstPersonTransitionStart, this.firstPersonTransitionTarget);
	}

	/**
	 * Samples this instance into a frame of resolved animation bone transforms.
	 *
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the sampled bone and action-anchor frame, or {@code null} when the requested value is unavailable
	 */
	public @Nullable PPlayerAnimationFrame sampleFrame(float partialTick)
	{
		int partialTickBits = Float.floatToIntBits(partialTick);
		if (this.cachedFrame != null && this.cachedFramePartialTickBits == partialTickBits)
			return this.cachedFrame;
		PBakedModel model = this.definition.modelData().getModel();
		if (model == null)
			return null;

		PAnimationPoseResolver<PPlayerAnimationInstance> resolver = new PAnimationPoseResolver<>(
				model,
				this.animationManager.getControllers().values(),
				(controller, tick) ->
				{
					MolangParser.Context context = new MolangParser.Context().
							query("anim_time", PAnimationEvaluationContext.ticksToSeconds(controller.getInterpolatedTime(tick))).
							randomSeed(this.animationManager.key().key());
					this.definition.populateMolangContext(this.player, this, controller, context, tick);
					return context;
				},
				partialTick);
		this.cachedFrame = new PPlayerAnimationFrame(this.definition, resolver);
		this.cachedFramePartialTickBits = partialTickBits;
		return this.cachedFrame;
	}

	/**
	 * Samples the named animation bone into a player-space pose contribution.
	 *
	 * @param boneName the animation bone name
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the sampled player bone contribution, or {@code null} when the requested value is unavailable
	 */
	@Nullable PPlayerBonePose sample(String boneName, float partialTick)
	{
		PPlayerAnimationFrame frame = sampleFrame(partialTick);
		return frame == null ? null : frame.canonicalModelDelta(boneName);
	}
}
