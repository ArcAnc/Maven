/**
 * @author ArcAnc
 * Created at: 27.02.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.renderer;


import com.arcanc.pulselib.content.animatable.AnimManagerKey;
import com.arcanc.pulselib.content.animatable.PAnimatable;
import com.arcanc.pulselib.content.animatable.PAnimationController;
import com.arcanc.pulselib.content.animatable.PAnimationManager;
import com.arcanc.pulselib.content.animatable.instance.InstanceAnimationManager;
import com.arcanc.pulselib.content.model.animation.PAnimationEvaluationContext;
import com.arcanc.pulselib.content.model.animation.PPose;
import com.arcanc.pulselib.content.model.baked.*;
import com.arcanc.pulselib.content.model.deformer.gpu.PGpuDeformerBuffers;
import com.arcanc.pulselib.content.renderer.modelData.PModelData;
import com.arcanc.pulselib.content.renderer.plan.PInstanceHeader;
import com.arcanc.pulselib.data.gecko.MolangParser;
import com.arcanc.pulselib.platform.PulseServices;
import com.arcanc.pulselib.util.PResourceCache;
import com.arcanc.pulselib.util.helpers.PLibHelper;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.class_922;

/**
 * Base entity renderer that samples PulseLib animation, submits bone meshes and renders bound model layers.
 *
 * @param <T> the animatable owner type
 */
public abstract class PEntityRenderer<T extends class_1297 & PAnimatable<T>> extends class_897<T>
	implements PRenderer<T>
{
	private final PModelData modelData;
	private final Function<class_2960, class_1921> renderType;
	private final Map<String, List<PEntityRenderLayer<T>>> renderLayers = new Object2ObjectOpenHashMap<>();

	/**
	 * Creates an entity renderer using the loader context, model selection and pipeline resolver.
	 *
	 * @param context the vanilla entity renderer construction context
	 * @param modelData the canonical model and loader selection
	 * @param renderType the render type
	 */
	public PEntityRenderer(class_5617.class_5618 context, PModelData modelData, Function<class_2960, class_1921> renderType)
	{
		super(context);
		this.modelData = modelData;
		this.renderType = renderType;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PModelData getModelData(T animatable)
	{
		return this.modelData;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public @Nullable PBakedModel getModel(T animatable)
	{
		return getModelData(animatable).getModel();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public class_1921 getRenderType(class_2960 texture)
	{
		return this.renderType.apply(texture);
	}

	/**
	 * Attaches an additional model render layer to the named entity bone.
	 *
	 * @param boneName the animation bone name
	 * @param renderLayer the render layer
	 */
	public void addRenderLayer(String boneName, PEntityRenderLayer<T> renderLayer)
	{
		this.renderLayers.compute(boneName, (bone, listLayers) ->
		{
			if (listLayers == null)
				listLayers = new ArrayList<>();
			listLayers.add(renderLayer);
			return listLayers;
		});
	}

	/**
	 * Samples entity animation, submits model and bound layer geometry, and preserves vanilla entity-render
	 * integration.
	 *
	 * @param entity the entity being animated or rendered
	 * @param entityYaw the entity yaw in degrees
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param poseStack the current model-to-render pose stack
	 * @param bufferSource the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 */
	@Override
	public void method_3936(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight)
	{
		try (var scope = PRenderContexts.enterEntity())
		{
			try
			{
				super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

				int packedOverlay = entity instanceof class_1309 living ? class_922.method_23622(living, 0.0f) : class_4608.field_21444;
				preSubmit(poseStack, entity, this :: getRenderType, bufferSource, packedLight, packedOverlay, partialTick);
				poseStack.method_22903();
				try
				{
					poseStack.method_22907(class_7833.field_40716.rotationDegrees(180));
					trueSubmit(poseStack, entity, this :: getRenderType, bufferSource, packedLight, packedOverlay, partialTick);
				}
				finally
				{
					poseStack.method_22909();
				}
				postSubmit(poseStack, entity, this :: getRenderType, bufferSource, packedLight, packedOverlay, partialTick);
			}
			catch (Throwable exception)
			{
				if (scope != null)
					scope.discard();
				throw exception;
			}
		}
	}

	/**
	 * Returns {@code null} because textures are resolved separately for each baked mesh.
	 *
	 * @param entity the entity being animated or rendered
	 * @return {@code null}; each baked mesh supplies its own texture selection
	 */
	@Override
	public @Nullable class_2960 method_3931(T entity)
	{
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void preSubmit(class_4587 poseStack, T animatable, Function<class_2960, class_1921> renderType, class_4597 bufferSource, int packedLight, int packedOverlay, float partialTick, @Nullable Object... additionalData)
	{

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void trueSubmit(class_4587 poseStack, T animatable, Function<class_2960, class_1921> renderType, class_4597 bufferSource, int packedLight, int packedOverlay, float partialTick, @Nullable Object... additionalData)
	{
		PBakedModel model = this.getModelData(animatable).getModel();
		if (model == null)
			return;

		PAnimationManager<T> manager = PLibHelper.getManager(animatable);
		manager.bindModel(model);
		InstanceAnimationManager.addManager(manager);

		Collection<PAnimationController<T>> controllers = manager.getControllers().values();
		Map<PAnimationController<T>, MolangParser.Context> molangContexts = prepareMolangContexts(animatable, manager.key(), controllers, partialTick);
		PPose pose = model.evaluate(controllers, molangContexts, partialTick);
		HeadRotation headRotation = null;
		if (animatable instanceof class_1309 livingEntity)
			headRotation = applyPositioning(livingEntity, poseStack, partialTick);

		if (this.renderLayers.isEmpty())
		{
			for (PBakedBone bone : model.bones())
				perBoneSubmit(animatable, poseStack, bone, pose, controllers, this.getModelData(animatable), renderType, - 1, packedLight, packedOverlay, partialTick, headRotation, null, null, null, null, molangContexts);
		}
		else
		{
			Map<String, Matrix4f> entityBonePoses = new Object2ObjectOpenHashMap<>();
			List<DeferredLayerSubmit> deferredLayers = new ArrayList<>();

			for (PBakedBone bone : model.bones())
				perBoneSubmit(animatable, poseStack, bone, pose, controllers, this.getModelData(animatable), renderType, -1, packedLight, packedOverlay, partialTick, headRotation, null, entityBonePoses, null, deferredLayers, molangContexts);

			for (DeferredLayerSubmit deferredLayer : deferredLayers)
				submitDeferredLayer(animatable, poseStack, controllers, molangContexts, partialTick, headRotation, entityBonePoses, deferredLayer);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void postSubmit(class_4587 poseStack, T animatable, Function<class_2960, class_1921> renderType, class_4597 bufferSource, int packedLight, int packedOverlay, float partialTick, @Nullable Object... additionalData)
	{

	}

	/**
	 * Submits the selected bone and its descendants using the sampled pose and inherited mesh render context.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param poseStack the current model-to-render pose stack
	 * @param bone the baked bone being sampled or submitted
	 * @param pose the indexed bone pose
	 * @param controllers the animation controllers in pose composition order
	 * @param data the canonical model and loader selection
	 * @param renderType the render type
	 * @param packedColor the packed ARGB vertex color
	 * @param packedLight the packed block and sky light coordinates
	 * @param packedOverlay the packed overlay texture coordinates
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param headRotation the interpolated head rotation used by bone-specific rendering; may be {@code null}
	 * @param renderLayer the render layer; may be {@code null}
	 * @param entityBonePoses the exact entity bone matrices captured for attached render layers; may be {@code null}
	 * @param layerTransform the additional local transform of an entity render layer; may be {@code null}
	 * @param deferredLayers the render layers waiting for their bound entity bone transforms; may be {@code null}
	 * @param molangContexts the frame-specific Molang context of each controller
	 */
	protected void perBoneSubmit(T animatable,
	                             class_4587 poseStack,
	                             PBakedBone bone,
	                             PPose pose,
	                             Collection<PAnimationController<T>> controllers,
								 PModelData data,
	                             Function<class_2960, class_1921> renderType,
	                             int packedColor,
	                             int packedLight,
	                             int packedOverlay,
	                             float partialTick,
	                             @Nullable HeadRotation headRotation,
	                             @Nullable PEntityRenderLayer<T> renderLayer,
	                             @Nullable Map<String, Matrix4f> entityBonePoses,
	                             @Nullable Matrix4f layerTransform,
	                             @Nullable List<DeferredLayerSubmit> deferredLayers,
	                             Map<PAnimationController<T>, MolangParser.Context> molangContexts)
	{
		PMeshRenderContext inherited = new PMeshRenderContext(
				renderType,
				packedColor,
				packedLight,
				packedOverlay);
		perBoneSubmit(animatable, poseStack, bone, pose, controllers, data, inherited, partialTick,
				headRotation, renderLayer, entityBonePoses, layerTransform, deferredLayers, molangContexts);
	}

	/**
	 * Submits the selected bone and its descendants using the sampled pose and inherited mesh render context.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param poseStack the current model-to-render pose stack
	 * @param bone the baked bone being sampled or submitted
	 * @param pose the indexed bone pose
	 * @param controllers the animation controllers in pose composition order
	 * @param data the canonical model and loader selection
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param headRotation the interpolated head rotation used by bone-specific rendering; may be {@code null}
	 * @param renderLayer the render layer; may be {@code null}
	 * @param entityBonePoses the exact entity bone matrices captured for attached render layers; may be {@code null}
	 * @param layerTransform the additional local transform of an entity render layer; may be {@code null}
	 * @param deferredLayers the render layers waiting for their bound entity bone transforms; may be {@code null}
	 * @param molangContexts the frame-specific Molang context of each controller
	 */
	protected void perBoneSubmit(T animatable,
	                             class_4587 poseStack,
	                             PBakedBone bone,
	                             PPose pose,
	                             Collection<PAnimationController<T>> controllers,
	                             PModelData data,
	                             PMeshRenderContext inherited,
	                             float partialTick,
	                             @Nullable HeadRotation headRotation,
	                             @Nullable PEntityRenderLayer<T> renderLayer,
	                             @Nullable Map<String, Matrix4f> entityBonePoses,
	                             @Nullable Matrix4f layerTransform,
	                             @Nullable List<DeferredLayerSubmit> deferredLayers,
	                             Map<PAnimationController<T>, MolangParser.Context> molangContexts)
	{
		int boneIndex = data.getModel().boneIndex(bone);
		poseStack.method_22903();
		if (renderLayer != null && entityBonePoses != null)
			applyBoundLayerBonePose(poseStack, bone, renderLayer, entityBonePoses, layerTransform);
		poseStack.method_46416(pose.translation(boneIndex).x(), pose.translation(boneIndex).y(), pose.translation(boneIndex).z());
		poseStack.method_22907(pose.rotation(boneIndex));
		poseStack.method_22905(pose.scale(boneIndex).x(), pose.scale(boneIndex).y(), pose.scale(boneIndex).z());
		if (bone.name().equals("head") && headRotation != null)
		{
			poseStack.method_22907(class_7833.field_40715.rotationDegrees(headRotation.headYaw()));
			poseStack.method_22907(class_7833.field_40713.rotationDegrees(headRotation.headPitch()));
		}
		if (renderLayer == null && entityBonePoses != null)
			entityBonePoses.put(bone.name(), new Matrix4f(poseStack.method_23760().method_23761()));

		PMeshRenderContext boneContext = renderLayer == null ?
				resolveBoneRender(animatable, bone, inherited, partialTick) :
				renderLayer.resolveBoneRender(animatable, bone, inherited, partialTick);

		if (renderLayer == null)
		{
			this.submitBone(animatable, bone, poseStack, data, controllers, boneContext, partialTick);
			List<PEntityRenderLayer<T>> layers = this.renderLayers.get(bone.name());
			if (layers != null)
				for (PEntityRenderLayer<T> layer : layers)
					if (layer.shouldRender(animatable))
					{
						poseStack.method_22903();
						Vector3f offset = layer.offset();
						poseStack.method_46416(offset.x(), offset.y(), offset.z());
						poseStack.method_22907(layer.rotation());
						Vector3f scale = layer.scale();
						poseStack.method_22905(scale.x(), scale.y(), scale.z());
						Matrix4f attachmentTransform = getLayerTransform(bone.name(), poseStack, entityBonePoses);
						if (deferredLayers != null)
							deferredLayers.add(new DeferredLayerSubmit(layer, new Matrix4f(poseStack.method_23760().method_23761()), attachmentTransform,
									boneContext.color(), boneContext.packedLight(), boneContext.packedOverlay()));
						else
							layer.submit(this, animatable, poseStack, controllers, molangContexts,
									boneContext.color(), boneContext.packedLight(), boneContext.packedOverlay(), partialTick,
									headRotation, entityBonePoses, attachmentTransform);

						poseStack.method_22909();
					}
		}
		else
			this.submitBone(animatable, bone, poseStack, data, controllers, boneContext, partialTick, renderLayer);

		if (!bone.children().isEmpty())
			for (PBakedBone child : bone.children())
				perBoneSubmit(animatable, poseStack, child, pose, controllers, data, boneContext, partialTick,
						headRotation, renderLayer, entityBonePoses, layerTransform, deferredLayers, molangContexts);

		poseStack.method_22909();
	}

	private void submitDeferredLayer(T animatable,
	                                 class_4587 poseStack,
	                                 Collection<PAnimationController<T>> controllers,
	                                 Map<PAnimationController<T>, MolangParser.Context> molangContexts,
	                                 float partialTick,
									 @Nullable HeadRotation headRotation,
	                                 Map<String, Matrix4f> entityBonePoses,
	                                 DeferredLayerSubmit deferredLayer)
	{
		poseStack.method_22903();
		poseStack.method_23760().method_23761().set(deferredLayer.attachmentPose);
		deferredLayer.layer.submit(
				this,
				animatable,
				poseStack,
				controllers,
				molangContexts,
				deferredLayer.packedColor,
				deferredLayer.packedLight,
				deferredLayer.packedOverlay,
				partialTick,
				headRotation,
				entityBonePoses,
				deferredLayer.layerTransform);
		poseStack.method_22909();
	}

	private Matrix4f getLayerTransform(String anchorBoneName, class_4587 poseStack, @Nullable Map<String, Matrix4f> entityBonePoses)
	{
		if (entityBonePoses == null)
			return new Matrix4f();
		Matrix4f anchorPose = entityBonePoses.get(anchorBoneName);
		if (anchorPose == null)
			return new Matrix4f();
		return new Matrix4f(anchorPose).invert().mul(poseStack.method_23760().method_23761());
	}

	private Map<PAnimationController<T>, MolangParser.Context> prepareMolangContexts(T animatable,
	                                                                                   AnimManagerKey key,
	                                                                                   Collection<PAnimationController<T>> controllers,
	                                                                                   float partialTick)
	{
		Map<PAnimationController<T>, MolangParser.Context> contexts = new Object2ObjectOpenHashMap<>();
		for (PAnimationController<T> controller : controllers)
		{
			MolangParser.Context context = new MolangParser.Context().
					query("anim_time", PAnimationEvaluationContext.ticksToSeconds(controller.getInterpolatedTime(partialTick))).
					randomSeed(key.key());
			populateMolangContext(animatable, controller, context, partialTick);
			contexts.put(controller, context);
		}
		return contexts;
	}

	/**
	 * Populates owner-specific Molang queries for this controller and render sample.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param controller the controller supplying playback and persistent expression state
	 * @param context the Molang context containing current frame and instance values
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected void populateMolangContext(T animatable,
	                                    PAnimationController<T> controller,
	                                    MolangParser.Context context,
	                                    float partialTick)
	{
	}

	private void applyBoundLayerBonePose(class_4587 poseStack,
	                                     PBakedBone bone,
	                                     PEntityRenderLayer<T> renderLayer,
	                                     Map<String, Matrix4f> entityBonePoses,
	                                     @Nullable Matrix4f layerTransform)
	{
		String entityBoneName = renderLayer.getBoundEntityBone(bone.name());
		if (entityBoneName == null)
			return;
		Matrix4f entityBonePose = entityBonePoses.get(entityBoneName);
		if (entityBonePose == null)
			return;
		Matrix4f pose = poseStack.method_23760().method_23761();
		pose.set(entityBonePose);
		pose.translate(-bone.basePosition().x(), -bone.basePosition().y(), -bone.basePosition().z());
		if (layerTransform != null)
			pose.mul(layerTransform);
	}

	/**
	 * Submits one bone hierarchy using the supplied model and controller inputs.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param poseStack the current model-to-render pose stack
	 * @param modelData the canonical model and loader selection
	 * @param controllers the animation controllers in pose composition order
	 * @param renderType the render type
	 * @param color the packed ARGB vertex color
	 * @param packedLight the packed block and sky light coordinates
	 * @param packedOverlay the packed overlay texture coordinates
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected void submitBone(T animatable,
	                          PBakedBone bone,
	                          class_4587 poseStack,
	                          PModelData modelData,
	                          Collection<PAnimationController<T>> controllers,
	                          Function<class_2960, class_1921> renderType,
	                          int color,
	                          int packedLight,
	                          int packedOverlay,
	                          float partialTick)
	{
		submitBone(animatable, bone, poseStack, modelData, controllers, renderType, color, packedLight, packedOverlay, partialTick, null);
	}
	/**
	 * Submits one bone hierarchy using the supplied model and controller inputs.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param poseStack the current model-to-render pose stack
	 * @param modelData the canonical model and loader selection
	 * @param controllers the animation controllers in pose composition order
	 * @param renderType the render type
	 * @param color the packed ARGB vertex color
	 * @param packedLight the packed block and sky light coordinates
	 * @param packedOverlay the packed overlay texture coordinates
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param renderLayer the render layer; may be {@code null}
	 */
	protected void submitBone(T animatable,
	                          PBakedBone bone,
	                          class_4587 poseStack,
	                          PModelData modelData,
	                          Collection<PAnimationController<T>> controllers,
	                          Function<class_2960, class_1921> renderType,
	                          int color,
	                          int packedLight,
	                          int packedOverlay,
	                          float partialTick,
	                          @Nullable PEntityRenderLayer<T> renderLayer)
	{
		submitBone(animatable, bone, poseStack, modelData, controllers,
				new PMeshRenderContext(renderType, color, packedLight, packedOverlay), partialTick, renderLayer);
	}

	/**
	 * Submits one bone hierarchy using the supplied model and controller inputs.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param poseStack the current model-to-render pose stack
	 * @param modelData the canonical model and loader selection
	 * @param controllers the animation controllers in pose composition order
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected void submitBone(T animatable,
	                          PBakedBone bone,
	                          class_4587 poseStack,
	                          PModelData modelData,
	                          Collection<PAnimationController<T>> controllers,
	                          PMeshRenderContext inherited,
	                          float partialTick)
	{
		submitBone(animatable, bone, poseStack, modelData, controllers, inherited, partialTick, null);
	}

	/**
	 * Submits one bone hierarchy using the supplied model and controller inputs.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param poseStack the current model-to-render pose stack
	 * @param modelData the canonical model and loader selection
	 * @param controllers the animation controllers in pose composition order
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param renderLayer the render layer; may be {@code null}
	 */
	protected void submitBone(T animatable,
	                          PBakedBone bone,
	                          class_4587 poseStack,
	                          PModelData modelData,
	                          Collection<PAnimationController<T>> controllers,
	                          PMeshRenderContext inherited,
	                          float partialTick,
	                          @Nullable PEntityRenderLayer<T> renderLayer)
	{
		Matrix4f matrix4fstack = new Matrix4f(poseStack.method_23760().method_23761());

		for (PBakedMesh mesh : bone.meshes())
		{
			if (mesh.textureReference().isEmpty())
				continue;

			PMeshRenderContext meshContext = renderLayer == null ?
					resolveMeshRender(animatable, bone, mesh, inherited, partialTick) :
					renderLayer.resolveMeshRender(animatable, bone, mesh, inherited, partialTick);
			PMeshRenderMaterial material = PMeshRenderMaterial.resolve(mesh, meshContext);

			class_1921 type = material.resolveRenderType(meshContext, PResourceCache.ATLAS_LOCATION);

			PGpuDeformerBuffers.Submission deformation = PGpuDeformerBuffers.submit(meshContext.deformation());
			PInstanceHeader instance = new PInstanceHeader(matrix4fstack, meshContext.color(), material.packedLight(), meshContext.packedOverlay(),
					deformation.operationOffset(), deformation.valueOffset(), deformation.operationCount());
			if (meshContext.deformation() == null || meshContext.deformation().stack().isEmpty())
				PRenderQueue.submitEntityMesh(type, material.mesh().geometry(), instance);
			else if (deformation.enabled())
				PRenderQueue.submitEntityMesh(type,
						PGpuDeformedMeshBuffers.resolve(material.mesh(), meshContext.deformation().subdivisionLevel()), instance);
			else
				PRenderQueue.submitEntityMesh(type, PDeformedMeshBuffers.resolve(material.mesh(), meshContext.deformation()), instance);
		}
	}

	/**
	 * Resolves render overrides inherited by the selected bone and its meshes.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the inherited or overridden mesh render inputs
	 */
	protected PMeshRenderContext resolveBoneRender(T animatable,
	                                               PBakedBone bone,
	                                               PMeshRenderContext inherited,
	                                               float partialTick)
	{
		return inherited;
	}

	/**
	 * Resolves final render overrides for one mesh of the selected bone.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param mesh the baked mesh geometry and material
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the inherited or overridden mesh render inputs
	 */
	protected PMeshRenderContext resolveMeshRender(T animatable,
	                                               PBakedBone bone,
	                                               PBakedMesh mesh,
	                                               PMeshRenderContext inherited,
	                                               float partialTick)
	{
		return inherited;
	}

	/**
	 * Applies entity positioning and returns the interpolated head rotation inputs.
	 *
	 * @param entity the entity being animated or rendered
	 * @param poseStack the current model-to-render pose stack
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the interpolated relative head yaw and pitch
	 */
	protected HeadRotation applyPositioning(class_1309 entity, class_4587 poseStack, float partialTick)
	{
		/// Vanilla copy paste
		boolean shouldSit = entity.method_5765() && (entity.method_5854() != null && PulseServices.PLATFORM.shouldRiderSit(entity.method_5854()));
		float bodyRot = class_3532.method_17821(partialTick, entity.field_6220, entity.field_6283);
		float headRot = class_3532.method_17821(partialTick, entity.field_6259, entity.field_6241);
		float diffAngle = headRot - bodyRot;
		if (shouldSit && entity.method_5854() instanceof class_1309 livingentity)
		{
			bodyRot = class_3532.method_17821(partialTick, livingentity.field_6220, livingentity.field_6283);
			diffAngle = headRot - bodyRot;
			float clampedAngle = class_3532.method_15363(class_3532.method_15393(diffAngle), -85f, 85f);

			bodyRot = headRot - clampedAngle;
			if (clampedAngle * clampedAngle > 2500f)
				bodyRot += clampedAngle * 0.2f;

			diffAngle = headRot - bodyRot;
		}

		if (class_922.method_38563(entity))
			diffAngle *= -1.0F;

		diffAngle = class_3532.method_15393(diffAngle);
		if (entity.method_41328(class_4050.field_18078))
		{
			class_2350 direction = entity.method_18401();
			if (direction != null)
			{
				float f3 = entity.method_18381(class_4050.field_18076) - 0.1F;
				poseStack.method_46416(-direction.method_10148() * f3, 0.0F, -direction.method_10165() * f3);
			}
		}

		float entityScale = entity.method_55693();
		poseStack.method_22905(entityScale, entityScale, entityScale);
		float age = entity.field_6012 + partialTick;
		this.setupRotations(entity, poseStack, age, bodyRot, partialTick, entityScale);
		float headPitch = class_3532.method_16439(partialTick, entity.field_6004, entity.method_36455());
		return new HeadRotation(diffAngle, headPitch);
	}

	/**
	 * Applies living-entity body, death, sleeping and movement rotations to the render pose.
	 *
	 * @param entity the entity being animated or rendered
	 * @param poseStack the current model-to-render pose stack
	 * @param bob the bob
	 * @param yBodyRot the interpolated body yaw in degrees
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param scale the model scale factor
	 */
	protected void setupRotations(class_1309 entity, class_4587 poseStack, float bob, float yBodyRot, float partialTick, float scale)
	{
		if (entity.method_32314())
			yBodyRot += (float) (Math.cos(entity.field_6012 * 3.25f) * Math.PI * 0.4F);

		if (!entity.method_41328(class_4050.field_18078))
			poseStack.method_22907(class_7833.field_40715.rotationDegrees(yBodyRot));

		if (entity.field_6213 > 0)
		{
			float f = ((float)entity.field_6213 + partialTick - 1.0F) / 20.0F * 1.6F;
			f = class_3532.method_15355(f);
			if (f > 1.0F)
				f = 1.0F;

			poseStack.method_22907(class_7833.field_40718.rotationDegrees(f * 90));
		}
		else if (entity.method_6123())
		{
			poseStack.method_22907(class_7833.field_40714.rotationDegrees(-90.0F - entity.method_36455()));
			poseStack.method_22907(class_7833.field_40716.rotationDegrees((entity.field_6012 + partialTick) * -75.0F));
		}
		else if (entity.method_41328(class_4050.field_18078))
		{
			class_2350 direction = entity.method_18401();
			float f1 = direction != null ? sleepDirectionToRotation(direction) : yBodyRot;
			poseStack.method_22907(class_7833.field_40716.rotationDegrees(f1));
			poseStack.method_22907(class_7833.field_40718.rotationDegrees(90));
			poseStack.method_22907(class_7833.field_40716.rotationDegrees(270.0F));
		}
		else if (class_922.method_38563(entity))
		{
			poseStack.method_46416(0.0F, (entity.method_17682() + 0.1F) / scale, 0.0F);
			poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
		}
	}

	private float sleepDirectionToRotation(class_2350 facing)
	{
		return switch (facing)
		{
			case field_11035 -> 90.0F;
			case field_11043 -> 270.0F;
			case field_11034 -> 180.0F;
			default -> 0.0F;
		};
	}

	/**
	 * Interpolated head yaw and pitch used while submitting entity bones.
	 *
	 * @param headYaw the head yaw
	 * @param headPitch the head pitch in degrees
	 */
	public record HeadRotation(float headYaw, float headPitch)
	{
	}

	/**
	 * Captured entity layer submission deferred until the required parent bone pose is known.
	 */
	protected final class DeferredLayerSubmit
	{
		private final PEntityRenderLayer<T> layer;
		private final Matrix4f attachmentPose;
		private final Matrix4f layerTransform;
		private final int packedColor;
		private final int packedLight;
		private final int packedOverlay;

		private DeferredLayerSubmit(PEntityRenderLayer<T> layer,
		                            Matrix4f attachmentPose,
		                            Matrix4f layerTransform,
		                            int packedColor,
		                            int packedLight,
		                            int packedOverlay)
		{
			this.layer = layer;
			this.attachmentPose = attachmentPose;
			this.layerTransform = layerTransform;
			this.packedColor = packedColor;
			this.packedLight = packedLight;
			this.packedOverlay = packedOverlay;
		}
	}
}
