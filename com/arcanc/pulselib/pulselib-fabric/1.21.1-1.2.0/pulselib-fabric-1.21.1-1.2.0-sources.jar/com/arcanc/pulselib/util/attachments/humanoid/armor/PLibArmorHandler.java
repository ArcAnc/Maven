/**
 * @author ArcAnc
 * Created at: 04.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.util.attachments.humanoid.armor;

import com.arcanc.pulselib.content.mixin.LivingEntityRendererAccessor;
import com.arcanc.pulselib.content.player.animation.attachment.PPlayerAnimatedAttachmentLayer;
import com.arcanc.pulselib.util.attachments.PLivingAttachmentLayer;
import com.arcanc.pulselib.util.attachments.humanoid.PHumanoidAttachmentLayer;
import net.minecraft.class_1007;
import net.minecraft.class_572;
import net.minecraft.class_897;
import net.minecraft.class_922;

/**
 * Installs living, humanoid and animated-player attachment layers on compatible renderers.
 */
public final class PLibArmorHandler
{
	/**
	 * Adds the PulseLib attachment layers supported by the supplied entity renderer.
	 *
	 * @param renderer the renderer
	 */
	@SuppressWarnings ( {"rawtypes", "unchecked"})
	public static void addLayers(class_897<?> renderer)
	{
		if (renderer instanceof class_1007 player)
		{
			((LivingEntityRendererAccessor)player).pulselib$addLayer(new PHumanoidAttachmentLayer(player));
			((LivingEntityRendererAccessor)player).pulselib$addLayer(new PPlayerAnimatedAttachmentLayer(player));
		}
		else if (renderer instanceof class_922 living)
		{
			if (living.method_4038() instanceof class_572)
				((LivingEntityRendererAccessor)living).pulselib$addLayer(new PHumanoidAttachmentLayer(living));
			else
				((LivingEntityRendererAccessor)living).pulselib$addLayer(new PLivingAttachmentLayer(living));
		}
	}
}
