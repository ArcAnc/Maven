/**
 * @author ArcAnc
 * Created at: 06.03.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package com.arcanc.pulselib.content.renderer.modelData;

import javax.annotation.ParametersAreNonnullByDefault;
