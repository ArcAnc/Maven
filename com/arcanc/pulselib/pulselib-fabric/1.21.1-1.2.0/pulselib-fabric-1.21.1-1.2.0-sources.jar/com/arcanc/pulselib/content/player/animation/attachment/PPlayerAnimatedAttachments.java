/**
 * @author ArcAnc
 * Created at: 23.09.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.player.animation.attachment;

import com.arcanc.pulselib.content.model.animation.PTransform;
import com.arcanc.pulselib.content.player.animation.PPlayerAnimationSpace;
import com.arcanc.pulselib.content.player.animation.PPlayerAnimationAnchor;
import com.arcanc.pulselib.content.player.animation.PPlayerAnimationAnchorPose;
import com.arcanc.pulselib.content.player.animation.PPlayerAnimations;
import com.arcanc.pulselib.content.player.animation.firstPerson.PFirstPersonRenderPresentation;
import com.arcanc.pulselib.content.player.animation.firstPerson.PPlayerFirstPersonAnchorPose;
import org.joml.Matrix4f;

import java.util.*;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;

/**
 * Registry and third-person dispatcher for semantic player-animation anchors.
 */
public final class PPlayerAnimatedAttachments
{
	private static final Map<PPlayerAnimationAnchor, List<PPlayerAnimatedAttachmentRenderer>> RENDERERS = new HashMap<>();

	private PPlayerAnimatedAttachments()
	{
	}

	/**
	 * Registers an attachment renderer for its declared player animation anchor.
	 *
	 * @param renderer the renderer
	 */
	public static void register(PPlayerAnimatedAttachmentRenderer renderer)
	{
		List<PPlayerAnimatedAttachmentRenderer> renderers = RENDERERS.computeIfAbsent(renderer.anchor(), ignored -> new ArrayList<>());
		if (!renderers.contains(renderer))
			renderers.add(renderer);
	}

	/**
	 * Renders registered attachments at the player's active third-person animation anchors.
	 *
	 * @param player the player whose animation or presentation is being processed
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	public static void renderThirdPerson(class_742 player, class_4587 poseStack,
	                                     class_4597 buffers, int packedLight, float partialTick)
	{
		for (PPlayerAnimationAnchorPose pose : PPlayerAnimations.animationAnchorPoses(player, partialTick))
		{
			List<PPlayerAnimatedAttachmentRenderer> renderers = RENDERERS.get(pose.anchor());
			if (renderers == null)
				continue;
			Matrix4f matrix = new Matrix4f();
			if (!PPlayerAnimations.attachmentMatrix(player, pose.animation(), pose.anchor(), partialTick, matrix))
			{
				continue;
			}
			for (PPlayerAnimatedAttachmentRenderer renderer : renderers.stream().
					sorted(Comparator.comparing(value -> value.getClass().getName())).toList())
			{
				poseStack.method_22903();
				try
				{
					poseStack.method_34425(matrix);
					renderer.render(new PPlayerAnimatedAttachmentContext(player, pose.animation(), pose.anchor(), pose.transform(),
						pose.weight(), false, poseStack, buffers, packedLight, partialTick));
				}
				finally
				{
					poseStack.method_22909();
				}
			}
		}
	}

	/**
	 * Renders animation-owned anchors from an already resolved first-person presentation.
	 *
	 * @param player the player whose animation or presentation is being processed
	 * @param presentation the presentation
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	public static void renderFirstPerson(class_742 player, PFirstPersonRenderPresentation presentation,
	                                     class_4587 poseStack, class_4597 buffers, int packedLight, float partialTick)
	{
		for (PPlayerFirstPersonAnchorPose pose : presentation.animationAnchors())
		{
			List<PPlayerAnimatedAttachmentRenderer> renderers = RENDERERS.get(pose.anchor());
			if (renderers == null)
				continue;
			for (PPlayerAnimatedAttachmentRenderer renderer : renderers.stream().
					sorted(Comparator.comparing(value -> value.getClass().getName())).toList())
			{
				poseStack.method_22903();
				try
				{
					Matrix4f matrix = new Matrix4f();
					if (PPlayerAnimations.firstPersonAttachmentMatrix(player, pose.animation(), pose.anchor(), partialTick, matrix))
					{
						PPlayerAnimationSpace.applyChannelOverride(matrix, pose.transform(), PTransform.fromMatrix(matrix));
					}
					else
					{
						pose.transform().matrix(matrix);
					}
					poseStack.method_34425(matrix);
					renderer.render(new PPlayerAnimatedAttachmentContext(player, pose.animation(), pose.anchor(), pose.transform(),
						pose.weight(), true, poseStack, buffers, packedLight, partialTick));
				}
				finally
				{
					poseStack.method_22909();
				}
			}
		}
	}
}
