/**
 * @author ArcAnc
 * Created at: 08.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.player.deformer.PDeformableCubeBakeScope;
import net.minecraft.class_5599;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Enables deformable cube baking for vanilla regular and slim player model layers.
 */
@Mixin(class_5599.class)
public class EntityModelSetMixin
{
	/**
	 * Bakes regular and slim player layers inside a deformable-cube scope.
	 *
	 * @param definition the immutable configuration to register or evaluate
	 * @param location the location
	 * @return the baked model root, using deformable cubes for supported player layers
	 */
	@Redirect(method = "bakeLayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/geom/builders/LayerDefinition;bakeRoot()Lnet/minecraft/client/model/geom/ModelPart;"))
	private class_630 pulselib$bakePlayerLayerWithDeformableCubes(class_5607 definition, class_5601 location)
	{
		String modelPath = location.method_35743().method_12832();
		if (!"minecraft".equals(location.method_35743().method_12836()) ||
				(!"player".equals(modelPath) && !"player_slim".equals(modelPath)))
			return definition.method_32109();
		try (PDeformableCubeBakeScope.Scope ignored = PDeformableCubeBakeScope.begin())
		{
			return definition.method_32109();
		}
	}
}
