/**
 * @author ArcAnc
 * Created at: 30.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.player.animation.firstPerson.*;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1007;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_811;
import net.minecraft.class_897;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Integrates PulseLib's version-independent first-person presentation into the
 * direct 1.21.1 hand renderer. Vanilla still computes equip, swing and use
 * transforms before these final arm and item submissions are replaced.
 */
@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin
{
	/**
	 * Samples and scopes the player presentation for the complete first-person hand pass.
	 *
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param player the player whose animation or presentation is being processed
	 * @param packedLight the packed block and sky light coordinates
	 * @param original the original implementation or unmodified value supplied by the render hook
	 */
	@WrapMethod(method = "renderHandsWithItems")
	private void pulselib$withFirstPersonPass(float partialTick, class_4587 poseStack,
	                                          class_4597.class_4598 buffers, class_746 player, int packedLight,
	                                          Operation<Void> original)
	{
		PFirstPersonRenderContexts.beginPass(player, partialTick);
		try { original.call(partialTick, poseStack, buffers, player, packedLight); }
		finally { PFirstPersonRenderContexts.endPass(); }
	}

	/**
	 * The BufferSource is still open immediately before the vanilla batch flush.
	 *
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param player the player whose animation or presentation is being processed
	 * @param packedLight the packed block and sky light coordinates
	 * @param ci the Mixin callback for the intercepted method
	 */
	@Inject(method = "renderHandsWithItems", at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;endBatch()V", shift = At.Shift.BEFORE))
	private void pulselib$renderFirstPersonAttachments(float partialTick, class_4587 poseStack,
	                                                   class_4597.class_4598 buffers, class_746 player, int packedLight,
	                                                   CallbackInfo ci)
	{
		var presentation = PFirstPersonRenderContexts.passPresentation();
		if (presentation != null) PPlayerFirstPersonRenderer.renderExtras(player, presentation, poseStack, buffers, packedLight, partialTick);
	}

	/**
	 * Captures the hand-pass basis and renders animated empty off-hand geometry when required.
	 *
	 * @param player the player whose animation or presentation is being processed
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param pitch the pitch angle in degrees
	 * @param hand the interaction hand being rendered
	 * @param swingProgress the vanilla hand swing animation progress
	 * @param stack the item stack supplying render or animation state
	 * @param equippedProgress the vanilla hand equip animation progress
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param original the original implementation or unmodified value supplied by the render hook
	 */
	@WrapMethod(method = "renderArmWithItem")
	private void pulselib$renderArmWithItem(class_742 player, float partialTick, float pitch,
	                                        class_1268 hand, float swingProgress, class_1799 stack, float equippedProgress,
	                                        class_4587 poseStack, class_4597 buffers, int packedLight, Operation<Void> original)
	{
		class_1306 arm = hand == class_1268.field_5808 ? player.method_6068() : player.method_6068().method_5928();
		PFirstPersonRenderContexts.push(hand, arm, stack, poseStack);
		try
		{
			original.call(player, partialTick, pitch, hand, swingProgress, stack, equippedProgress, poseStack, buffers, packedLight);
			if (hand == class_1268.field_5810 && stack.method_7960()) renderHeldArm(player, PFirstPersonRenderContexts.current(), poseStack, buffers, packedLight);
		}
		finally { PFirstPersonRenderContexts.pop(); }
	}

	/**
	 * Applies the sampled right-arm presentation around vanilla first-person arm rendering.
	 *
	 * @param renderer the renderer
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param player the player whose animation or presentation is being processed
	 * @param original the original implementation or unmodified value supplied by the render hook
	 */
	@WrapOperation(method = "renderPlayerArm", at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/entity/player/PlayerRenderer;renderRightHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V"))
	private void pulselib$renderRightArm(class_1007 renderer, class_4587 poseStack, class_4597 buffers,
	                                    int packedLight, class_742 player, Operation<Void> original)
	{
		renderArm(renderer, poseStack, buffers, packedLight, player, original);
	}

	/**
	 * Applies the sampled left-arm presentation around vanilla first-person arm rendering.
	 *
	 * @param renderer the renderer
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param player the player whose animation or presentation is being processed
	 * @param original the original implementation or unmodified value supplied by the render hook
	 */
	@WrapOperation(method = "renderPlayerArm", at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/entity/player/PlayerRenderer;renderLeftHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V"))
	private void pulselib$renderLeftArm(class_1007 renderer, class_4587 poseStack, class_4597 buffers,
	                                   int packedLight, class_742 player, Operation<Void> original)
	{
		renderArm(renderer, poseStack, buffers, packedLight, player, original);
	}

	/**
	 * Selects hidden, vanilla or animated held-item rendering from the current presentation.
	 *
	 * @param renderer the renderer
	 * @param entity the entity being animated or rendered
	 * @param stack the item stack supplying render or animation state
	 * @param displayContext the display context
	 * @param leftHand the left hand
	 * @param poseStack the current model-to-render pose stack
	 * @param buffers the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param original the original implementation or unmodified value supplied by the render hook
	 */
	@WrapOperation(method = "renderArmWithItem", at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"))
	private void pulselib$renderHeldItem(class_759 renderer, class_1309 entity, class_1799 stack,
	                                    class_811 displayContext, boolean leftHand, class_4587 poseStack,
	                                    class_4597 buffers, int packedLight, Operation<Void> original)
	{
		PFirstPersonRenderContext context = PFirstPersonRenderContexts.current();
		if (context == null || context.map())
		{
			original.call(renderer, entity, stack, displayContext, leftHand, poseStack, buffers, packedLight);
			return;
		}
		PFirstPersonItemPose itemPose = context.arm() == class_1306.field_6183 ? context.presentation().rightItem() : context.presentation().leftItem();
		renderHeldArm(entity, context, poseStack, buffers, packedLight);
		if (itemPose.mode() == PFirstPersonRenderMode.HIDDEN) return;
		if (itemPose.mode() == PFirstPersonRenderMode.VANILLA || itemPose.transform() == null)
		{
			original.call(renderer, entity, stack, displayContext, leftHand, poseStack, buffers, packedLight);
			return;
		}
		poseStack.method_22903();
		try
		{
			if (itemPose.transformMode() == PFirstPersonTransformMode.ADDITIVE) poseStack.method_34425(itemPose.transform().matrix());
			else PFirstPersonPoseStack.replaceLocalPose(poseStack, context.basePose(), context.baseNormal(),
					PVanillaFirstPersonItemResolver.resolveItemOrigin(context.arm(), itemPose.transform()));
			original.call(renderer, entity, stack, displayContext, leftHand, poseStack, buffers, packedLight);
		}
		finally { poseStack.method_22909(); }
	}

	private static void renderArm(class_1007 renderer, class_4587 poseStack, class_4597 buffers, int packedLight,
	                              class_742 player, Operation<Void> original)
	{
		PFirstPersonRenderContext context = PFirstPersonRenderContexts.current();
		if (context == null || context.map()) { original.call(renderer, poseStack, buffers, packedLight, player); return; }
		PFirstPersonArmPose armPose = context.arm() == class_1306.field_6183 ? context.presentation().rightArm() : context.presentation().leftArm();
		if (armPose.mode() == PFirstPersonRenderMode.HIDDEN) return;
		if (armPose.mode() == PFirstPersonRenderMode.VANILLA || armPose.transform() == null)
		{
			original.call(renderer, poseStack, buffers, packedLight, player);
			return;
		}
		poseStack.method_22903();
		try
		{
			PFirstPersonPoseStack.replaceLocalPose(poseStack, context.basePose(), context.baseNormal(),
					PVanillaFirstPersonArmResolver.resolveArmOrigin(context.arm(), armPose.transform()));
			original.call(renderer, poseStack, buffers, packedLight, player);
		}
		finally { poseStack.method_22909(); }
	}

	private static void renderHeldArm(class_1309 entity, @Nullable PFirstPersonRenderContext context,
	                                  class_4587 poseStack, class_4597 buffers, int packedLight)
	{
		if (context == null || context.map() || !(entity instanceof class_742 player) || player.method_5767()) return;
		PFirstPersonArmPose armPose = context.arm() == class_1306.field_6183 ? context.presentation().rightArm() : context.presentation().leftArm();
		if (armPose.mode() != PFirstPersonRenderMode.ANIMATED || armPose.transform() == null) return;
		class_897<?> candidate = class_310.method_1551().method_1561().method_3953(player);
		if (!(candidate instanceof class_1007 renderer)) return;
		poseStack.method_22903();
		try
		{
			PFirstPersonPoseStack.replaceLocalPose(poseStack, context.basePose(), context.baseNormal(),
					PVanillaFirstPersonArmResolver.resolveArmOrigin(context.arm(), armPose.transform()));
			if (context.arm() == class_1306.field_6183) renderer.method_4220(poseStack, buffers, packedLight, player);
			else renderer.method_4221(poseStack, buffers, packedLight, player);
		}
		finally { poseStack.method_22909(); }
	}
}
