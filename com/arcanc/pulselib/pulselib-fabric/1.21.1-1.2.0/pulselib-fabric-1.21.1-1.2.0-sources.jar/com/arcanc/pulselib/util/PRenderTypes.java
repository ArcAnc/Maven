/**
 * @author ArcAnc
 * Created at: 27.01.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.util;


import com.arcanc.pulselib.content.mixin.RenderTypeAccessor;
import com.arcanc.pulselib.content.model.textures.PAlphaMode;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_296;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import net.minecraft.class_5944;

/**
 * Built-in triangle pipelines, shader accessors and render-type material classification.
 */
public final class PRenderTypes
{
	private PRenderTypes()
	{
	}

	/**
	 * Creates and caches triangle render types for alpha, emissive and isolated rendering policies.
	 */
	public static final class RenderTypeProvider
	{
		private RenderTypeProvider()
		{
		}

		private static final Set<class_1921> OIT_TRANSLUCENT_TYPES = Collections.newSetFromMap(new IdentityHashMap<>());
		private static final Set<class_1921> OIT_TRANSLUCENT_EMISSIVE_TYPES = Collections.newSetFromMap(new IdentityHashMap<>());
		private static final Function<class_2960, class_1921> TRIANGLES_SOLID = class_156.method_34866(RenderTypeProvider :: createTrianglesSolid);
		private static final Function<class_2960, class_1921> TRIANGLES_CUTOUT = class_156.method_34866(RenderTypeProvider :: createTrianglesCutout);
		private static final Function<class_2960, class_1921> TRIANGLES_TRANSLUCENT = class_156.method_34866(RenderTypeProvider :: createTrianglesTranslucent);
		private static final Function<class_2960, class_1921> TRIANGLES_GUI = class_156.method_34866(RenderTypeProvider :: createTrianglesGui);
		private static final Function<class_2960, class_1921> TRIANGLES_IMMEDIATE = class_156.method_34866(RenderTypeProvider :: createTrianglesImmediate);
		private static final Function<class_2960, class_1921> TRIANGLES_SOLID_EMISSIVE = class_156.method_34866(RenderTypeProvider :: createTrianglesSolidEmissive);
		private static final Function<class_2960, class_1921> TRIANGLES_CUTOUT_EMISSIVE = class_156.method_34866(RenderTypeProvider :: createTrianglesCutoutEmissive);
		private static final Function<class_2960, class_1921> TRIANGLES_TRANSLUCENT_EMISSIVE = class_156.method_34866(RenderTypeProvider :: createTrianglesTranslucentEmissive);
		private static final Function<class_2960, class_1921> TRIANGLES_GUI_EMISSIVE = class_156.method_34866(RenderTypeProvider :: createTrianglesGuiEmissive);
		private static final Function<class_2960, class_1921> TRIANGLES_IMMEDIATE_EMISSIVE = class_156.method_34866(RenderTypeProvider :: createTrianglesImmediateEmissive);
		
		private static class_1921 createTrianglesSolid(class_2960 location)
		{
			return createTriangles("triangles_solid", location,
					ShadersProvider.StateShard.TRIANGLES_SOLID_STATE_SHARD,
					class_4668.field_21364);
		}
		
		private static class_1921 createTrianglesCutout(class_2960 location)
		{
			return createTriangles("triangles_cutout", location,
					ShadersProvider.StateShard.TRIANGLES_CUTOUT_STATE_SHARD,
					class_4668.field_21364);
		}
		
		private static class_1921 createTrianglesTranslucent(class_2960 location)
		{
			class_1921 type = createTriangles("triangles_translucent", location,
					ShadersProvider.StateShard.TRIANGLES_TRANSLUCENT_STATE_SHARD,
					class_4668.field_21370);
			OIT_TRANSLUCENT_TYPES.add(type);
			return type;
		}
		
		private static class_1921 createTrianglesGui(class_2960 location)
		{
			return createTriangles("triangles_gui", location,
					ShadersProvider.StateShard.TRIANGLES_IMMEDIATE_LIT_STATE_SHARD,
					class_4668.field_21370);
		}
		
		private static class_1921 createTrianglesImmediate(class_2960 location)
		{
			return createTriangles("triangles_immediate", location,
					ShadersProvider.StateShard.TRIANGLES_IMMEDIATE_LIT_STATE_SHARD,
					class_4668.field_21364);
		}
		
		private static class_1921 createTrianglesSolidEmissive(class_2960 location)
		{
			return createTriangles("triangles_solid_emissive", location,
					ShadersProvider.StateShard.TRIANGLES_SOLID_EMISSIVE_STATE_SHARD,
					class_4668.field_21364);
		}
		
		private static class_1921 createTrianglesCutoutEmissive(class_2960 location)
		{
			return createTriangles("triangles_cutout_emissive", location,
					ShadersProvider.StateShard.TRIANGLES_CUTOUT_EMISSIVE_STATE_SHARD,
					class_4668.field_21364);
		}
		
		private static class_1921 createTrianglesTranslucentEmissive(class_2960 location)
		{
			class_1921 type = createTriangles("triangles_translucent_emissive", location,
					ShadersProvider.StateShard.TRIANGLES_TRANSLUCENT_EMISSIVE_STATE_SHARD,
					class_4668.field_21370);
			OIT_TRANSLUCENT_EMISSIVE_TYPES.add(type);
			return type;
		}
		
		private static class_1921 createTrianglesGuiEmissive(class_2960 location)
		{
			return createTriangles("triangles_gui_emissive", location,
					ShadersProvider.StateShard.TRIANGLES_IMMEDIATE_EMISSIVE_STATE_SHARD,
					class_4668.field_21370);
		}
		
		private static class_1921 createTrianglesImmediateEmissive(class_2960 location)
		{
			return createTriangles("triangles_immediate_emissive", location,
					ShadersProvider.StateShard.TRIANGLES_IMMEDIATE_EMISSIVE_STATE_SHARD,
					class_4668.field_21364);
		}

		private static class_1921 createTriangles(String name,
		                                          class_2960 location,
		                                          class_4668.class_5942 shader,
		                                          class_4668.class_4685 transparency)
		{
			class_1921.class_4688.class_4689 state = class_1921.class_4688.method_23598().
					method_34578(shader).
					method_34577(new class_4668.class_4683(location, false, false)).
					method_23615(transparency).
					method_23603(class_4668.field_21345).
					method_23608(class_4668.field_21383).
					method_23611(class_4668.field_21385);
			return class_1921.method_24049(
					PLibDatabase.rl(name).toString(),
					VertexFormatProvider.POSITION_TEX_NORMAL,
					class_293.class_5596.field_27379,
					1536,
					true,
					false,
					state.method_23617(true));
		}
		
		/**
		 * Returns the cached lit render pipeline for opaque triangle geometry.
		 *
		 * @param location the location
		 * @return the cached lit render pipeline for opaque triangle geometry
		 */
		public static class_1921 trianglesSolid(class_2960 location)
		{
			return TRIANGLES_SOLID.apply(location);
		}
		
		/**
		 * Returns the cached lit render pipeline for alpha-tested triangle geometry.
		 *
		 * @param location the location
		 * @return the cached lit render pipeline for alpha-tested triangle geometry
		 */
		public static class_1921 trianglesCutout(class_2960 location)
		{
			return TRIANGLES_CUTOUT.apply(location);
		}
		
		/**
		 * Returns the cached lit render pipeline for translucent triangle geometry.
		 *
		 * @param location the location
		 * @return the cached lit render pipeline for translucent triangle geometry
		 */
		public static class_1921 trianglesTranslucent(class_2960 location)
		{
			return TRIANGLES_TRANSLUCENT.apply(location);
		}
		
		/**
		 * Returns the cached lit render pipeline for isolated GUI triangle geometry.
		 *
		 * @param location the location
		 * @return the cached lit render pipeline for isolated GUI triangle geometry
		 */
		public static class_1921 trianglesGui(class_2960 location)
		{
			return TRIANGLES_GUI.apply(location);
		}
		
		/**
		 * Returns the cached lit render pipeline for immediate triangle geometry.
		 *
		 * @param location the location
		 * @return the cached lit render pipeline for immediate triangle geometry
		 */
		public static class_1921 trianglesImmediate(class_2960 location)
		{
			return TRIANGLES_IMMEDIATE.apply(location);
		}
		
		/**
		 * Returns the cached emissive render pipeline for opaque triangle geometry.
		 *
		 * @param location the location
		 * @return the cached emissive render pipeline for opaque triangle geometry
		 */
		public static class_1921 trianglesSolidEmissive(class_2960 location)
		{
			return TRIANGLES_SOLID_EMISSIVE.apply(location);
		}
		
		/**
		 * Returns the cached emissive render pipeline for alpha-tested triangle geometry.
		 *
		 * @param location the location
		 * @return the cached emissive render pipeline for alpha-tested triangle geometry
		 */
		public static class_1921 trianglesCutoutEmissive(class_2960 location)
		{
			return TRIANGLES_CUTOUT_EMISSIVE.apply(location);
		}
		
		/**
		 * Returns the cached emissive render pipeline for translucent triangle geometry.
		 *
		 * @param location the location
		 * @return the cached emissive render pipeline for translucent triangle geometry
		 */
		public static class_1921 trianglesTranslucentEmissive(class_2960 location)
		{
			return TRIANGLES_TRANSLUCENT_EMISSIVE.apply(location);
		}
		
		/**
		 * Returns the cached emissive render pipeline for isolated GUI triangle geometry.
		 *
		 * @param location the location
		 * @return the cached emissive render pipeline for isolated GUI triangle geometry
		 */
		public static class_1921 trianglesGuiEmissive(class_2960 location)
		{
			return TRIANGLES_GUI_EMISSIVE.apply(location);
		}
		
		/**
		 * Returns the cached emissive render pipeline for immediate triangle geometry.
		 *
		 * @param location the location
		 * @return the cached emissive render pipeline for immediate triangle geometry
		 */
		public static class_1921 trianglesImmediateEmissive(class_2960 location)
		{
			return TRIANGLES_IMMEDIATE_EMISSIVE.apply(location);
		}

		/**
		 * Selects the built-in triangle pipeline matching the supplied alpha policy.
		 *
		 * @param alphaMode the material alpha handling policy
		 * @param location the location
		 * @return the vanilla render pipeline
		 */
		public static class_1921 forAlphaMode(PAlphaMode alphaMode, class_2960 location)
		{
			return switch (alphaMode)
			{
				case OPAQUE -> trianglesSolid(location);
				case CUTOUT -> trianglesCutout(location);
				case TRANSLUCENT -> trianglesTranslucent(location);
				case AUTO -> throw new IllegalArgumentException("AUTO alpha mode must be resolved before selecting a render type");
			};
		}
		
		/**
		 * Selects the emissive variant corresponding to a recognized built-in render type.
		 *
		 * @param renderType the render type
		 * @param location the location
		 * @return the vanilla render pipeline
		 */
		public static class_1921 emissiveVariant(class_1921 renderType, class_2960 location)
		{
			if (renderType == trianglesSolid(location))
				return trianglesSolidEmissive(location);
			if (renderType == trianglesCutout(location))
				return trianglesCutoutEmissive(location);
			if (renderType == trianglesTranslucent(location))
				return trianglesTranslucentEmissive(location);
			if (renderType == trianglesGui(location))
				return trianglesGuiEmissive(location);
			if (renderType == trianglesImmediate(location))
				return trianglesImmediateEmissive(location);
			return renderType;
		}

		/**
		 * Returns whether the pipeline participates in PulseLib weighted transparency.
		 *
		 * @param renderType the render type
		 * @return whether the pipeline participates in PulseLib weighted transparency
		 */
		public static boolean usesOit(class_1921 renderType)
		{
			return OIT_TRANSLUCENT_TYPES.contains(renderType) || OIT_TRANSLUCENT_EMISSIVE_TYPES.contains(renderType);
		}

		/**
		 * Returns whether the pipeline uses emissive weighted transparency.
		 *
		 * @param renderType the render type
		 * @return whether the pipeline uses emissive weighted transparency
		 */
		public static boolean usesEmissiveOit(class_1921 renderType)
		{
			return OIT_TRANSLUCENT_EMISSIVE_TYPES.contains(renderType);
		}
	}
	
	/**
	 * Vertex layouts shared by baked geometry and PulseLib shaders.
	 */
	public static final class VertexFormatProvider
	{
		private VertexFormatProvider()
		{
		}

		/**
		 * Triangle vertex layout containing position, texture coordinates and normal.
		 */
		public static final class_293 POSITION_TEX_NORMAL = class_293.method_60833().
				method_60842("Position", class_296.field_52107).
				method_60842("UV0", class_296.field_52109).
				method_60842("Normal", class_296.field_52113).
				method_60841(1).
				method_60840();
	}
	
	/**
	 * Reload-populated shader instances used by the built-in render pipelines.
	 */
	public static final class ShadersProvider
	{
		private ShadersProvider()
		{
		}

		/**
		 * Render-state shard used to access shader registration and selection helpers.
		 */
		private static final class StateShard
		{
			private static final class_4668.class_5942 TRIANGLES_SOLID_STATE_SHARD = new class_4668.class_5942(() -> ShadersProvider.TRIANGLES_SOLID_SHADER);
			private static final class_4668.class_5942 TRIANGLES_CUTOUT_STATE_SHARD = new class_4668.class_5942(() -> ShadersProvider.TRIANGLES_CUTOUT_SHADER);
			private static final class_4668.class_5942 TRIANGLES_TRANSLUCENT_STATE_SHARD = new class_4668.class_5942(() -> ShadersProvider.TRIANGLES_TRANSLUCENT_SHADER);
			private static final class_4668.class_5942 TRIANGLES_IMMEDIATE_LIT_STATE_SHARD = new class_4668.class_5942(() -> ShadersProvider.TRIANGLES_IMMEDIATE_LIT_SHADER);
			private static final class_4668.class_5942 TRIANGLES_SOLID_EMISSIVE_STATE_SHARD = new class_4668.class_5942(() -> ShadersProvider.TRIANGLES_SOLID_EMISSIVE_SHADER);
			private static final class_4668.class_5942 TRIANGLES_CUTOUT_EMISSIVE_STATE_SHARD = new class_4668.class_5942(() -> ShadersProvider.TRIANGLES_CUTOUT_EMISSIVE_SHADER);
			private static final class_4668.class_5942 TRIANGLES_TRANSLUCENT_EMISSIVE_STATE_SHARD = new class_4668.class_5942(() -> ShadersProvider.TRIANGLES_TRANSLUCENT_EMISSIVE_SHADER);
			private static final class_4668.class_5942 TRIANGLES_IMMEDIATE_EMISSIVE_STATE_SHARD = new class_4668.class_5942(() -> ShadersProvider.TRIANGLES_IMMEDIATE_EMISSIVE_SHADER);
		}
		
		@Nullable
		private static class_5944 TRIANGLES_SOLID_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_CUTOUT_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_TRANSLUCENT_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_IMMEDIATE_LIT_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_SOLID_EMISSIVE_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_CUTOUT_EMISSIVE_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_TRANSLUCENT_EMISSIVE_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_IMMEDIATE_EMISSIVE_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_OIT_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_OIT_EMISSIVE_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_OIT_DEPTH_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_OIT_DEPTH_EMISSIVE_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_OIT_DEPTH_PEEL_SHADER;
		@Nullable
		private static class_5944 TRIANGLES_OIT_DEPTH_PEEL_EMISSIVE_SHADER;
		@Nullable
		private static class_5944 OIT_COMPOSITE_SHADER;
		@Nullable
		private static class_5944 OIT_FABULOUS_COMPOSITE_SHADER;
		@Nullable
		private static class_5944 OIT_FABULOUS_METADATA_SHADER;
		
		/**
		 * Returns the triangles solid.
		 *
		 * @return the triangles solid, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesSolid()
		{
			return TRIANGLES_SOLID_SHADER;
		}
		/**
		 * Returns the triangles cutout.
		 *
		 * @return the triangles cutout, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesCutout()
		{
			return TRIANGLES_CUTOUT_SHADER;
		}
		/**
		 * Returns the triangles translucent.
		 *
		 * @return the triangles translucent, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesTranslucent()
		{
			return TRIANGLES_TRANSLUCENT_SHADER;
		}
		/**
		 * Returns the triangles immediate lit.
		 *
		 * @return the triangles immediate lit, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesImmediateLit()
		{
			return TRIANGLES_IMMEDIATE_LIT_SHADER;
		}
		/**
		 * Returns the triangles solid emissive.
		 *
		 * @return the triangles solid emissive, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesSolidEmissive()
		{
			return TRIANGLES_SOLID_EMISSIVE_SHADER;
		}
		/**
		 * Returns the triangles cutout emissive.
		 *
		 * @return the triangles cutout emissive, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesCutoutEmissive()
		{
			return TRIANGLES_CUTOUT_EMISSIVE_SHADER;
		}
		/**
		 * Returns the triangles translucent emissive.
		 *
		 * @return the triangles translucent emissive, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesTranslucentEmissive()
		{
			return TRIANGLES_TRANSLUCENT_EMISSIVE_SHADER;
		}
		/**
		 * Returns the triangles immediate emissive.
		 *
		 * @return the triangles immediate emissive, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesImmediateEmissive()
		{
			return TRIANGLES_IMMEDIATE_EMISSIVE_SHADER;
		}

		/**
		 * Returns the lit or emissive weighted-transparency accumulation shader.
		 *
		 * @param emissive the emissive
		 * @return the lit or emissive weighted-transparency accumulation shader, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesOit(boolean emissive)
		{
			return emissive ? TRIANGLES_OIT_EMISSIVE_SHADER : TRIANGLES_OIT_SHADER;
		}

		/**
		 * Returns the lit or emissive translucent-depth shader.
		 *
		 * @param emissive the emissive
		 * @return the lit or emissive translucent-depth shader, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesOitDepth(boolean emissive)
		{
			return emissive ? TRIANGLES_OIT_DEPTH_EMISSIVE_SHADER : TRIANGLES_OIT_DEPTH_SHADER;
		}

		/**
		 * Returns the lit or emissive depth-peeling shader.
		 *
		 * @param emissive the emissive
		 * @return the lit or emissive depth-peeling shader, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 trianglesOitDepthPeel(boolean emissive)
		{
			return emissive ? TRIANGLES_OIT_DEPTH_PEEL_EMISSIVE_SHADER : TRIANGLES_OIT_DEPTH_PEEL_SHADER;
		}

		/**
		 * Returns the oit fabulous composite.
		 *
		 * @return the oit fabulous composite, or {@code null} before the requested shader has been registered
		 */
		@Nullable
		public static class_5944 oitFabulousComposite()
		{
			return OIT_FABULOUS_COMPOSITE_SHADER;
		}

		/**
		 * Returns the oit fabulous metadata.
		 *
		 * @return the oit fabulous metadata, or {@code null} before the requested shader has been registered
		 */
		@Nullable
		public static class_5944 oitFabulousMetadata()
		{
			return OIT_FABULOUS_METADATA_SHADER;
		}

		/**
		 * Returns the oit composite.
		 *
		 * @return the oit composite, or {@code null} before the requested shader has been registered
		 */
		public static @Nullable class_5944 oitComposite()
		{
			return OIT_COMPOSITE_SHADER;
		}
		
		/**
		 * Declares every built-in shader through the active loader's shader registration bridge.
		 *
		 * @param event the typed animation event to dispatch
		 * @throws IOException if the source resource cannot be read
		 */
		public static void registerShaders(final ShaderRegistrar event) throws IOException
		{
			{
				registerShader(event, "triangles_solid", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_SOLID_SHADER = shader);
				registerShader(event, "triangles_cutout", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_CUTOUT_SHADER = shader);
				registerShader(event, "triangles_translucent", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_TRANSLUCENT_SHADER = shader);

				registerShader(event, "triangles_solid_emissive", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_SOLID_EMISSIVE_SHADER = shader);
				registerShader(event, "triangles_cutout_emissive", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_CUTOUT_EMISSIVE_SHADER = shader);
				registerShader(event, "triangles_translucent_emissive", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_TRANSLUCENT_EMISSIVE_SHADER = shader);

				registerShader(event, "triangles_immediate_lit", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_IMMEDIATE_LIT_SHADER = shader);
				registerShader(event, "triangles_immediate_emissive", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_IMMEDIATE_EMISSIVE_SHADER = shader);

				registerShader(event, "triangles_oit", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_OIT_SHADER = shader);
				registerShader(event, "triangles_oit_emissive", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_OIT_EMISSIVE_SHADER = shader);
				registerShader(event, "triangles_oit_depth", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_OIT_DEPTH_SHADER = shader);
				registerShader(event, "triangles_oit_depth_emissive", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_OIT_DEPTH_EMISSIVE_SHADER = shader);
				registerShader(event, "triangles_oit_depth_peel", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_OIT_DEPTH_PEEL_SHADER = shader);
				registerShader(event, "triangles_oit_depth_peel_emissive", VertexFormatProvider.POSITION_TEX_NORMAL,
						shader -> TRIANGLES_OIT_DEPTH_PEEL_EMISSIVE_SHADER = shader);
				registerShader(event, "oit_composite", class_290.field_29336,
						shader -> OIT_COMPOSITE_SHADER = shader);
				registerShader(event, "oit_fabulous_composite", class_290.field_29336,
						shader -> OIT_FABULOUS_COMPOSITE_SHADER = shader);
				registerShader(event, "oit_fabulous_metadata", class_290.field_29336,
						shader -> OIT_FABULOUS_METADATA_SHADER = shader);
			}
		}

		private static void registerShader(ShaderRegistrar event,
		                                   String name,
		                                   class_293 format,
		                                   Consumer<class_5944> setter) throws IOException
		{
			event.register(PLibDatabase.rl(name), format, shader ->
			{
				setter.accept(shader);
				PLibDatabase.LOGGER.debug("PulseLib initialized shader {}", name);
			});
		}
	}
	
	/**
	 * Loader-neutral callback for registering and receiving a shader instance.
	 */
	@FunctionalInterface
	public interface ShaderRegistrar
	{
		/**
		 * Registers a shader resource with its vertex layout and reload assignment callback.
		 *
		 * @param id the namespaced resource or registration identifier
		 * @param format the vertex layout used to interpret vertex bytes
		 * @param setter the setter
		 * @throws IOException if the source resource cannot be read
		 */
		void register(class_2960 id, class_293 format, Consumer<class_5944> setter) throws IOException;
	}
	
	/**
	 * Reads the transparency shard of a compatible composite render type.
	 *
	 * @param renderType the render type
	 * @return the transparency shard, or an empty optional for an incompatible render type
	 */
	@ApiStatus.Internal
	public static Optional<class_4668.class_4685> getTransparencyState(class_1921 renderType)
	{
		if (renderType instanceof RenderTypeAccessor.CompositeRenderTypeAccessor composite)
		{
			class_1921.class_4688 state = composite.pulselib$getState();
			return Optional.of(((RenderTypeAccessor.CompositeStateAccessor)(Object)state).pulselib$getTransparencyState());
		}
		return Optional.empty();
	}
	
	/**
	 * Returns whether the render type uses a translucent transparency state.
	 *
	 * @param renderType the render type
	 * @return whether the render type uses a translucent transparency state
	 */
	@ApiStatus.Internal
	public static boolean isTranslucent(class_1921 renderType)
	{
		return getTransparencyState(renderType).
				map(transparency -> transparency != class_4668.class_4685.field_21364).
				orElse(false);
	}
}
