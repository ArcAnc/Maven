/**
 * @author ArcAnc
 * Created at: 27.01.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.renderer;


import com.arcanc.pulselib.content.animatable.AnimManagerKey;
import com.arcanc.pulselib.content.animatable.PAnimatable;
import com.arcanc.pulselib.content.animatable.PAnimationController;
import com.arcanc.pulselib.content.animatable.PAnimationManager;
import com.arcanc.pulselib.content.animatable.instance.InstanceAnimationManager;
import com.arcanc.pulselib.content.model.animation.PAnimationEvaluationContext;
import com.arcanc.pulselib.content.model.animation.PPose;
import com.arcanc.pulselib.content.model.baked.*;
import com.arcanc.pulselib.content.model.deformer.gpu.PGpuDeformerBuffers;
import com.arcanc.pulselib.content.renderer.modelData.PModelData;
import com.arcanc.pulselib.content.renderer.plan.PDynamicGeometry;
import com.arcanc.pulselib.content.renderer.plan.PInstanceHeader;
import com.arcanc.pulselib.data.gecko.MolangParser;
import com.arcanc.pulselib.util.PRenderTypes;
import com.arcanc.pulselib.util.PResourceCache;
import com.arcanc.pulselib.util.helpers.PLibHelper;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4668;
import net.minecraft.class_7833;
import net.minecraft.class_827;

/**
 * Base renderer for animatable block entities with per-bone submission and Molang query hooks.
 *
 * @param <T> the animatable owner type
 */
public abstract class PBlockRenderer<T extends class_2586 & PAnimatable<T>>
		implements PRenderer<T>, class_827<T>
{
	private final PModelData modelData;
	private final Function<class_2960, class_1921> renderType;
	
	/**
	 * Creates a block-entity renderer using the supplied model and texture-to-pipeline resolver.
	 *
	 * @param modelData the canonical model and loader selection
	 * @param renderType the render type
	 */
	public PBlockRenderer(PModelData modelData, Function<class_2960, class_1921> renderType)
	{
		this.modelData = modelData;
		this.renderType = renderType;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public PModelData getModelData(T animatable)
	{
		return this.modelData;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public @Nullable PBakedModel getModel(T animatable)
	{
		return getModelData(animatable).getModel();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public class_1921 getRenderType(class_2960 texture)
	{
		return this.renderType.apply(texture);
	}
	
	/**
	 * Samples block-entity animation and submits the model with the block-facing orientation and render
	 * inputs.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param poseStack the current model-to-render pose stack
	 * @param bufferSource the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param packedOverlay the packed overlay texture coordinates
	 */
	@Override
	public void method_3569(T animatable, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay)
	{
		poseStack.method_22903();
		poseStack.method_46416(0.5f, 0, 0.5f);
		tryRotateToRealRotation(poseStack, getAnimatableFacing(animatable));
		preSubmit(poseStack, animatable, this :: getRenderType, bufferSource, packedLight, packedOverlay, partialTick);
		trueSubmit(poseStack, animatable, this :: getRenderType, bufferSource, packedLight, packedOverlay, partialTick);
		postSubmit(poseStack, animatable, this :: getRenderType, bufferSource, packedLight, packedOverlay, partialTick);
		poseStack.method_22909();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void preSubmit(class_4587 poseStack, T animatable, Function<class_2960, class_1921> renderType, class_4597 bufferSource, int packedLight, int packedOverlay, float partialTick, @Nullable Object... additionalData)
	{
	
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void trueSubmit(class_4587 poseStack, T animatable, Function<class_2960, class_1921> renderType, class_4597 bufferSource, int packedLight, int packedOverlay, float partialTick, @Nullable Object... additionalData)
	{
		PBakedModel model = this.getModelData(animatable).getModel();
		if (model == null)
			return;
		PAnimationManager<T> manager = PLibHelper.getManager(animatable);
		manager.bindModel(model);
		Collection<PAnimationController<T>> controllers = manager.getControllers().values();
		Map<PAnimationController<T>, MolangParser.Context> molangContexts = prepareMolangContexts(animatable, manager.key(), controllers, partialTick);
		InstanceAnimationManager.addManager(manager);
		
		PPose pose = model.evaluate(controllers, molangContexts, partialTick);
		model.bones().forEach(bone -> perBoneSubmit(animatable, poseStack, bone, pose, controllers, molangContexts, renderType, -1, packedLight, packedOverlay, partialTick));
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void postSubmit(class_4587 poseStack, T animatable, Function<class_2960, class_1921> renderType, class_4597 bufferSource, int packedLight, int packedOverlay, float partialTick, @Nullable Object... additionalData)
	{
	
	}
	
	/**
	 * Submits the selected bone and its descendants using the sampled pose and inherited mesh render context.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param poseStack the current model-to-render pose stack
	 * @param bone the baked bone being sampled or submitted
	 * @param pose the indexed bone pose
	 * @param controllers the animation controllers in pose composition order
	 * @param molangContexts the frame-specific Molang context of each controller
	 * @param renderType the render type
	 * @param packedColor the packed ARGB vertex color
	 * @param packedLight the packed block and sky light coordinates
	 * @param packedOverlay the packed overlay texture coordinates
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected void perBoneSubmit(T animatable, class_4587 poseStack, PBakedBone bone, PPose pose, Collection<PAnimationController<T>> controllers, Map<PAnimationController<T>, MolangParser.Context> molangContexts, Function<class_2960, class_1921> renderType, int packedColor, int packedLight, int packedOverlay, float partialTick)
	{
		PMeshRenderContext inherited = new PMeshRenderContext(
				renderType,
				packedColor,
				packedLight,
				packedOverlay);
		perBoneSubmit(animatable, poseStack, bone, pose, controllers, molangContexts, inherited, partialTick);
	}

	/**
	 * Submits the selected bone and its descendants using the sampled pose and inherited mesh render context.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param poseStack the current model-to-render pose stack
	 * @param bone the baked bone being sampled or submitted
	 * @param pose the indexed bone pose
	 * @param controllers the animation controllers in pose composition order
	 * @param molangContexts the frame-specific Molang context of each controller
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected void perBoneSubmit(T animatable, class_4587 poseStack, PBakedBone bone, PPose pose, Collection<PAnimationController<T>> controllers, Map<PAnimationController<T>, MolangParser.Context> molangContexts, PMeshRenderContext inherited, float partialTick)
	{
		PModelData data = this.getModelData(animatable);
		int boneIndex = data.getModel().boneIndex(bone);
		poseStack.method_22903();
		poseStack.method_46416(pose.translation(boneIndex).x(), pose.translation(boneIndex).y(), pose.translation(boneIndex).z());
		poseStack.method_22907(pose.rotation(boneIndex));
		poseStack.method_22905(pose.scale(boneIndex).x(), pose.scale(boneIndex).y(), pose.scale(boneIndex).z());
		
		PMeshRenderContext boneContext = resolveBoneRender(animatable, bone, inherited, partialTick);
		this.submitBone(animatable, bone, poseStack, data, controllers, boneContext, partialTick);
		
		if (!bone.children().isEmpty())
			bone.children().forEach(child -> perBoneSubmit(animatable, poseStack, child, pose, controllers, molangContexts, boneContext, partialTick));

		poseStack.method_22909();
	}

	private Map<PAnimationController<T>, MolangParser.Context> prepareMolangContexts(T animatable,
	                                                                                   AnimManagerKey key,
	                                                                                   Collection<PAnimationController<T>> controllers,
	                                                                                   float partialTick)
	{
		Map<PAnimationController<T>, MolangParser.Context> contexts = new Object2ObjectOpenHashMap<>();
		for (PAnimationController<T> controller : controllers)
		{
			MolangParser.Context context = new MolangParser.Context().
					query("anim_time", PAnimationEvaluationContext.ticksToSeconds(controller.getInterpolatedTime(partialTick))).
					randomSeed(key.key());
			populateMolangContext(animatable, controller, context, partialTick);
			contexts.put(controller, context);
		}
		return contexts;
	}

	/**
	 * Populates owner-specific Molang queries for this controller and render sample.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param controller the controller supplying playback and persistent expression state
	 * @param context the Molang context containing current frame and instance values
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected void populateMolangContext(T animatable,
	                                    PAnimationController<T> controller,
	                                    MolangParser.Context context,
	                                    float partialTick)
	{
	}
	
	/**
	 * Applies the block-facing orientation to the current render pose.
	 *
	 * @param poseStack the current model-to-render pose stack
	 * @param facing the facing
	 */
	protected void tryRotateToRealRotation(class_4587 poseStack, class_2350 facing)
	{
		if (facing.method_10166().method_10179())
			poseStack.method_22907(class_7833.field_40716.rotationDegrees(facing.method_10144()));
		else
			poseStack.method_22907(class_7833.field_40714.rotationDegrees(90 * facing.method_10163().method_10264()));
	}
	
	/**
	 * Returns the block-facing direction used to orient the animatable model.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @return the block-facing direction used to orient the animatable model
	 */
	protected class_2350 getAnimatableFacing(T animatable)
	{
		class_2680 blockState = animatable.method_11010();
		class_2350 dir = class_2350.field_11043;
		
		if (blockState.method_28498(class_2741.field_12481))
			dir = blockState.method_11654(class_2741.field_12481);
		
		if (blockState.method_28498(class_2741.field_12525))
			dir = blockState.method_11654(class_2741.field_12525);
		
		if (dir.method_10166() ==  class_2350.class_2351.field_11051)
			dir = dir.method_10153();
		return dir;
	}
	
	/**
	 * Submits one bone hierarchy using the supplied model and controller inputs.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param poseStack the current model-to-render pose stack
	 * @param modelData the canonical model and loader selection
	 * @param controllers the animation controllers in pose composition order
	 * @param renderType the render type
	 * @param color the packed ARGB vertex color
	 * @param packedLight the packed block and sky light coordinates
	 * @param packedOverlay the packed overlay texture coordinates
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected void submitBone(T animatable,
	                          PBakedBone bone,
	                          class_4587 poseStack,
	                          PModelData modelData,
	                          Collection<PAnimationController<T>> controllers,
	                          Function<class_2960, class_1921> renderType,
	                          int color,
	                          int packedLight,
	                          int packedOverlay,
	                          float partialTick)
	{
		submitBone(animatable, bone, poseStack, modelData, controllers,
				new PMeshRenderContext(renderType, color, packedLight, packedOverlay), partialTick);
	}

	/**
	 * Submits one bone hierarchy using the supplied model and controller inputs.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param poseStack the current model-to-render pose stack
	 * @param modelData the canonical model and loader selection
	 * @param controllers the animation controllers in pose composition order
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 */
	protected void submitBone(T animatable,
	                          PBakedBone bone,
	                          class_4587 poseStack,
	                          PModelData modelData,
	                          Collection<PAnimationController<T>> controllers,
	                          PMeshRenderContext inherited,
	                          float partialTick)
	{
		Matrix4f matrix4fstack = new Matrix4f(poseStack.method_23760().method_23761());

		bone.meshes().forEach(mesh ->
		{
			if (mesh.textureReference().isEmpty())
				return;
			
			PMeshRenderContext meshContext = resolveMeshRender(animatable, bone, mesh, inherited, partialTick);
			PMeshRenderMaterial material = PMeshRenderMaterial.resolve(mesh, meshContext);
			
			class_1921 type = material.resolveRenderType(meshContext, PResourceCache.ATLAS_LOCATION);
			
			PGpuDeformerBuffers.Submission deformation = PGpuDeformerBuffers.submit(meshContext.deformation());
			PRenderTypes.getTransparencyState(type).ifPresent(transparency ->
			{
				PInstanceHeader instanceData = new PInstanceHeader(matrix4fstack, meshContext.color(), material.packedLight(), meshContext.packedOverlay(),
						deformation.operationOffset(), deformation.valueOffset(), deformation.operationCount());
				boolean staticGeometry = meshContext.deformation() == null || meshContext.deformation().stack().isEmpty();
				if (staticGeometry)
				{
					if (transparency == class_4668.class_4685.field_21364)
						PRenderQueue.submitBlockEntityMesh(type, material.mesh().geometry(), instanceData);
					else
						PRenderQueue.submitBlockEntityTranslucentMesh(type, material.mesh().geometry(), instanceData);
				}
				else if (deformation.enabled())
				{
					if (transparency == class_4668.class_4685.field_21364)
						PRenderQueue.submitBlockEntityMesh(type,
								PGpuDeformedMeshBuffers.resolve(material.mesh(), meshContext.deformation().subdivisionLevel()), instanceData);
					else
						PRenderQueue.submitBlockEntityTranslucentMesh(type,
								PGpuDeformedMeshBuffers.resolve(material.mesh(), meshContext.deformation().subdivisionLevel()), instanceData);
				}
				else
				{
					PDynamicGeometry buffer = PDeformedMeshBuffers.resolve(material.mesh(), meshContext.deformation());
					if (transparency == class_4668.class_4685.field_21364)
						PRenderQueue.submitBlockEntityMesh(type, buffer, instanceData);
					else
						PRenderQueue.submitBlockEntityTranslucentMesh(type, buffer, instanceData);
				}
			});
		});
	}

	/**
	 * Resolves render overrides inherited by the selected bone and its meshes.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the inherited or overridden mesh render inputs
	 */
	protected PMeshRenderContext resolveBoneRender(T animatable,
	                                               PBakedBone bone,
	                                               PMeshRenderContext inherited,
	                                               float partialTick)
	{
		return inherited;
	}
	
	/**
	 * Resolves final render overrides for one mesh of the selected bone.
	 *
	 * @param animatable the owner whose animation state is being processed
	 * @param bone the baked bone being sampled or submitted
	 * @param mesh the baked mesh geometry and material
	 * @param inherited the render inputs inherited from the parent bone or renderer
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @return the inherited or overridden mesh render inputs
	 */
	protected PMeshRenderContext resolveMeshRender(T animatable,
	                                               PBakedBone bone,
	                                               PBakedMesh mesh,
	                                               PMeshRenderContext inherited,
	                                               float partialTick)
	{
		return inherited;
	}
}
