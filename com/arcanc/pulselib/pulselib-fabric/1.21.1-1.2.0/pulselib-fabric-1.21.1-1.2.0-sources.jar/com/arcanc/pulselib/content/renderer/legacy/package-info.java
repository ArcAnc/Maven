/**
 * @author ArcAnc
 * Created at: 12.10.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

/**
 * Minecraft OpenGL execution backend, shared geometry storage and weighted transparency.
 */
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package com.arcanc.pulselib.content.renderer.legacy;

import javax.annotation.ParametersAreNonnullByDefault;
