/**
 * @author ArcAnc
 * Created at: 13.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.model.baked;

import com.arcanc.pulselib.content.model.PMeshPrimitive;
import com.arcanc.pulselib.content.model.textures.PTextureAlphaClassifier;
import com.arcanc.pulselib.content.renderer.legacy.GlGeometryDataFactory;
import com.arcanc.pulselib.content.renderer.plan.PGeometryData;
import com.arcanc.pulselib.content.model.textures.atlas.PLibMetadata;
import com.arcanc.pulselib.util.PRenderTypes;
import com.arcanc.pulselib.util.PResourceCache;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_1058;
import net.minecraft.class_287;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_9799;
import net.minecraft.class_9801;

/**
 * Caches baked mesh variants that use overridden texture resources.
 */
public final class PMeshTextureVariants
{
	private static final Map<PBakedMesh, Map<class_2960, PBakedMesh>> VARIANTS = new IdentityHashMap<>();

	private PMeshTextureVariants()
	{
	}

	/**
	 * Returns a mesh variant using the supplied texture.
	 *
	 * @param mesh the baked mesh geometry and material
	 * @param texture the texture resource location; may be {@code null}
	 * @return a mesh variant using the supplied texture
	 */
	public static PBakedMesh resolve(PBakedMesh mesh, @Nullable class_2960 texture)
	{
		if (texture == null)
			return mesh;
		class_2960 sprite = PResourceCache.spriteId(texture);
		if (sprite.equals(mesh.textureLocation()))
			return mesh;
		return VARIANTS.computeIfAbsent(mesh, ignored -> new HashMap<>()).computeIfAbsent(sprite,
				location -> bake(mesh, location));
	}

	/**
	 * Discards cached mesh texture variants.
	 */
	@ApiStatus.Internal
	public static void clear()
	{
		for (Map<class_2960, PBakedMesh> variants : VARIANTS.values())
			for (PBakedMesh variant : variants.values())
			{
				PDeformedMeshBuffers.close(variant);
				PGpuDeformedMeshBuffers.close(variant);
			}
		VARIANTS.clear();
	}

	private static PBakedMesh bake(PBakedMesh base, class_2960 texture)
	{
		PMeshPrimitive source = base.source();
		class_1058 sprite = PResourceCache.getTextureAtlas().method_4608(texture);
		boolean emissive = sprite.method_45851().method_52848().method_43041(PLibMetadata.TYPE).
				map(PLibMetadata :: isEmissive).orElse(false);
		try (class_9799 bytes = new class_9799(source.vertexCount() * PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL.method_1362()))
		{
			class_287 builder = sprite.method_45851().method_45816().method_12832().equals("missingno") ?
					new class_287(bytes, class_293.class_5596.field_27379, PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL) :
					new AtlasBufferBuilder(bytes, class_293.class_5596.field_27379, PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL, sprite);
			for (int vertex = 0; vertex < source.vertexCount(); vertex++)
				builder.method_22912(source.positions().get(vertex * 3), source.positions().get(vertex * 3 + 1), source.positions().get(vertex * 3 + 2)).
						method_22913(source.uvs().get(vertex * 2), source.uvs().get(vertex * 2 + 1)).
						method_22914(source.normals().get(vertex * 3), source.normals().get(vertex * 3 + 1), source.normals().get(vertex * 3 + 2));
			PGeometryData geometry;
			try (class_9801 data = builder.method_60800())
			{
				geometry = GlGeometryDataFactory.capture(data, source,
						PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL.method_1362());
			}
			return new PBakedMesh(base.uuid(), geometry, base.textureReference(), emissive,
					PTextureAlphaClassifier.resolve(sprite.method_45851()), source, texture);
		}
	}
}
