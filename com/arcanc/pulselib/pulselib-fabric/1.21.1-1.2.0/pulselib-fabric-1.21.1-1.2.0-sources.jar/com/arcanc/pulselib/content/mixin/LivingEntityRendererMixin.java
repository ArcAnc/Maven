/**
 * @author ArcAnc
 * Created at: 30.07.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.player.animation.PPlayerAnimations;
import com.arcanc.pulselib.content.player.deformer.PPlayerMeshDeformers;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_922;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies player pose animation and deformation around vanilla living-entity rendering.
 *
 * @param <T> the entity type rendered or animated by this contract
 * @param <M> the entity type rendered or animated by this contract
 */
@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309, M extends class_583<T>>
{
	@Unique private @Nullable PPlayerAnimations.PPlayerModelPose pulselib$playerPose;

	/**
	 * Vanilla living-entity model temporarily modified during player animation rendering.
	 */
	@Shadow protected M model;

	/**
	 * Applies player animation and mesh deformation before the living model renders.
	 *
	 * @param entity the entity being animated or rendered
	 * @param entityYaw the entity yaw in degrees
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param poseStack the current model-to-render pose stack
	 * @param bufferSource the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param ci the Mixin callback for the intercepted method
	 */
	@Inject(
			method = "render",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/model/EntityModel;setupAnim(Lnet/minecraft/world/entity/Entity;FFFFF)V",
					shift = At.Shift.AFTER))
	private void pulselib$applyPlayerAnimations(T entity,
	                                             float entityYaw,
	                                             float partialTick,
	                                             class_4587 poseStack,
	                                             class_4597 bufferSource,
	                                             int packedLight,
	                                             CallbackInfo ci)
	{
		if (!(entity instanceof class_1657 player) || !(this.model instanceof class_591<?> playerModel))
			return;

		this.pulselib$playerPose = PPlayerAnimations.apply(
				player,
				playerModel,
				partialTick,
				PPlayerAnimations.allParts());
		PPlayerMeshDeformers.apply(player, playerModel, partialTick);
		PPlayerAnimations.applyRoot(player, poseStack, partialTick);
	}

	/**
	 * Restores vanilla model-part transforms after living entity rendering.
	 *
	 * @param entity the entity being animated or rendered
	 * @param entityYaw the entity yaw in degrees
	 * @param partialTick the interpolation fraction between the previous and current game ticks
	 * @param poseStack the current model-to-render pose stack
	 * @param bufferSource the vanilla vertex buffer source
	 * @param packedLight the packed block and sky light coordinates
	 * @param ci the Mixin callback for the intercepted method
	 */
	@Inject(method = "render", at = @At("RETURN"))
	private void pulselib$restorePlayerAnimations(T entity,
	                                               float entityYaw,
	                                               float partialTick,
	                                               class_4587 poseStack,
	                                               class_4597 bufferSource,
	                                               int packedLight,
	                                               CallbackInfo ci)
	{
		if (!(entity instanceof class_1657) || !(this.model instanceof class_591<?>))
			return;

		if (this.pulselib$playerPose != null)
		{
			this.pulselib$playerPose.restore();
			this.pulselib$playerPose = null;
		}
	}
}
