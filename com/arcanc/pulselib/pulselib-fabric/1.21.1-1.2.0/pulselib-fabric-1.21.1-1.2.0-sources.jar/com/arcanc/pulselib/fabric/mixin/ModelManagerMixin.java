/**
 * @author ArcAnc
 * Created at: 12.10.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.fabric.mixin;

import com.arcanc.pulselib.util.PResourceCache;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1092;
import net.minecraft.class_2960;

/**
 * Adds the PulseLib texture atlas to Fabric model-manager atlas construction.
 */
@Mixin (class_1092.class)
public abstract class ModelManagerMixin
{
	/**
	 * Adds the PulseLib atlas mapping without mutating the original atlas map.
	 *
	 * @param original the original implementation or unmodified value supplied by the render hook
	 * @return a copy of the atlas map containing the PulseLib atlas
	 */
	@ModifyArg (method = "<init>", at = @At (value = "INVOKE",
		target = "Lnet/minecraft/client/resources/model/AtlasSet;<init>(Ljava/util/Map;Lnet/minecraft/client/renderer/texture/TextureManager;)V"), index = 0)
	private Map<class_2960, class_2960> pulselib$addAtlas(Map<class_2960, class_2960> original)
	{
		Map<class_2960, class_2960> atlases = new LinkedHashMap<>(original);
		atlases.put(PResourceCache.ATLAS_LOCATION, PResourceCache.ATLAS_FILE_LOCATION);
		return atlases;
	}
}
