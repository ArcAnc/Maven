/**
 * @author ArcAnc
 * Created at: 27.01.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.util;


import com.arcanc.pulselib.content.model.*;
import com.arcanc.pulselib.content.model.baked.*;
import com.arcanc.pulselib.content.model.deformer.gpu.PGpuDeformerBuffers;
import com.arcanc.pulselib.content.model.resource.PModelResource;
import com.arcanc.pulselib.content.model.textures.PTextureAlphaClassifier;
import com.arcanc.pulselib.content.model.textures.atlas.PLibMetadata;
import com.arcanc.pulselib.content.renderer.PRenderQueue;
import com.arcanc.pulselib.content.renderer.legacy.GlGeometryDataFactory;
import com.arcanc.pulselib.content.renderer.plan.PGeometryData;
import com.arcanc.pulselib.data.PModelLoader;
import com.arcanc.pulselib.data.gecko.PGeckoModelLoader;
import com.arcanc.pulselib.data.gltf.PGltfModelLoader;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1058;
import net.minecraft.class_287;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import net.minecraft.class_9799;
import net.minecraft.class_9801;

/**
 * Reloads registered source models, resolves their textures and publishes baked render models.
 */
public class PModelCache
{
	private static @Nullable Map<class_2960, PBakedModel> MODELS;
	private static final Map<class_2960, PModelLoader> MODEL_LOADERS = Stream.of(PGltfModelLoader.INSTANCE, PGeckoModelLoader.INSTANCE).
			collect(Collectors.toMap(
			PModelLoader :: id,
			Function.identity(),
			(oldV, newV) ->
			{
				throw new IllegalStateException("Duplicate model loader id: " + oldV.id());
			},
			Object2ObjectOpenHashMap :: new));
	
	/**
	 * Returns the currently published baked model cache.
	 *
	 * @return the currently published baked model cache, or {@code null} before baked models have been published
	 */
	public static @Nullable Map<class_2960, PBakedModel> getModels()
	{
		return MODELS;
	}
	
	/**
	 * Registers a model loader under its declared identifier.
	 *
	 * @param modelLoader the model loader
	 */
	public static void registerModelLoader(PModelLoader modelLoader)
	{
		if (MODEL_LOADERS.containsKey(modelLoader.id()))
			return;
		
		MODEL_LOADERS.put(modelLoader.id(), modelLoader);
	}
	
	/**
	 * Removes the loader registered under the supplied identifier.
	 *
	 * @param loaderId the model loader identifier
	 */
	public static void unregisterModelLoader(class_2960 loaderId)
	{
		MODEL_LOADERS.remove(loaderId);
	}
	
	/**
	 * Returns the currently registered model loaders.
	 *
	 * @return the currently registered model loaders
	 */
	public static List<PModelLoader> getModelLoaders()
	{
		return List.copyOf(MODEL_LOADERS.values());
	}
	
	/**
	 * Finds the model loader registered under the supplied identifier.
	 *
	 * @param loaderId the model loader identifier
	 * @return the matching loader, or an empty optional when unregistered
	 */
	public static Optional<PModelLoader> getModelLoader(class_2960 loaderId)
	{
		return Optional.ofNullable(MODEL_LOADERS.get(loaderId));
	}
	
	/**
	 * Prepares source models asynchronously, waits for the reload barrier and publishes baked models on the
	 * game executor.
	 *
	 * @param stage the stage
	 * @param resourceManager the resource manager used to locate source assets
	 * @param preparationsProfiler the profiler for background reload preparation
	 * @param reloadProfiler the profiler for applying the resource reload
	 * @param backgroundExecutor the executor used to read and prepare model resources
	 * @param gameExecutor the executor used to publish game-thread reload results
	 * @return a future completing when prepared models have been published
	 */
	@ApiStatus.Internal
	public static CompletableFuture<Void> reload(class_3302.class_4045 stage,
	                                             class_3300 resourceManager,
	                                             class_3695 preparationsProfiler,
	                                             class_3695 reloadProfiler,
	                                             Executor backgroundExecutor,
	                                             Executor gameExecutor)
	{
		long start = System.nanoTime();
		Map<class_2960, PModel> models = new ConcurrentHashMap<>();
		return loadModels(backgroundExecutor, resourceManager, models :: put).
				thenCompose(stage :: method_18352).
				thenAcceptAsync(empty ->
				{
					if (PModelCache.MODELS != null)
						clearCaches();
					PModelCache.MODELS = bakeModels(models);
					PLibDatabase.LOGGER.info("PulseLib model reload: baked {} models in {} ms", MODELS.size(), (System.nanoTime() - start) / 1_000_000);
				},
				gameExecutor);
	}
	
	private static void clearCaches()
	{
		PRenderQueue.cleanup();
		PMeshTextureVariants.clear();
		PTextureAlphaClassifier.clear();
		if (MODELS != null)
		{
			MODELS.forEach(($, model) ->
					model.bones().forEach(PModelCache :: clearBoneCache));
			MODELS = null;
		}
		PGpuDeformerBuffers.clearDefinitions();
	}

	private static void clearBoneCache(PBakedBone bone)
	{
		bone.meshes().forEach(mesh ->
		{
			PDeformedMeshBuffers.close(mesh);
			PGpuDeformedMeshBuffers.close(mesh);
		});
		bone.children().forEach(PModelCache :: clearBoneCache);
	}
	
	private static Map<class_2960, PBakedModel> bakeModels(Map<class_2960, PModel> rawModels)
	{
		Map<class_2960, PBakedModel> bakedModelMap = new Object2ObjectOpenHashMap<>();
		for (Map.Entry<class_2960, PModel> rawModel : rawModels.entrySet())
		{
			PModel model = rawModel.getValue();
			class_2960 modelId = rawModel.getKey();
			Map<UUID, PBakedBone.PBakedBoneBuilder> bakedBoneBuilder = new HashMap<>();
			for (PBone bone : model.bones.values())
			{
				bakedBoneBuilder.put(
						bone.uuid(),
						new PBakedBone.PBakedBoneBuilder(
								bone.uuid(),
								bone.name(),
								new Vector3f(bone.pivot()),
								new Quaternionf(bone.baseRotation()).normalize()
						)
				);
			}
			
			for (Map.Entry<UUID, Pair<UUID, List<UUID>>> bone2MeshesEntry : model.boneMeshes.entrySet())
			{
				PBakedBone.PBakedBoneBuilder builder = bakedBoneBuilder.get(bone2MeshesEntry.getKey());
				
				Map<PMaterial, List<PMeshPrimitive>> byMaterial = new LinkedHashMap<>();
				for (UUID meshUUID : bone2MeshesEntry.getValue().getSecond())
				{
					PMesh mesh = model.meshes.get(meshUUID);
					for (PMeshPrimitive primitive : mesh.primitives())
						byMaterial.computeIfAbsent(primitive.material(), ignored -> new ArrayList<>()).add(primitive);
				}
				for (List<PMeshPrimitive> primitives : byMaterial.values())
					bakePrimitive(modelId, UUID.randomUUID(), PMeshPrimitive.merge(primitives), builder);
			}
			
			for (PBone bone : model.bones.values())
			{
				PBone parentBone = bone.parent();
				if (parentBone == null)
					continue;
				
				PBakedBone.PBakedBoneBuilder child =
						bakedBoneBuilder.get(bone.uuid());
				
				PBakedBone.PBakedBoneBuilder parent =
						bakedBoneBuilder.get(parentBone.uuid());
				
				child.parent = parent;
				parent.children.add(child);
			}
			
			List<PBakedBone> rootBones = new ArrayList<>();
			
			for (PBakedBone.PBakedBoneBuilder builder : bakedBoneBuilder.values())
				if (builder.parent == null)
					rootBones.add(bakeBone(builder, null));
			
			bakedModelMap.put(
					rawModel.getKey(),
					new PBakedModel(ImmutableList.copyOf(rootBones),
							ImmutableMap.copyOf(model.animations))
			);
		}
		
		return bakedModelMap;
	}

	private static void bakePrimitive(class_2960 modelId, UUID meshId, PMeshPrimitive primitive,
	                                  PBakedBone.PBakedBoneBuilder builder)
	{
		String reference = primitive == null || primitive.material() == null ? "<missing>" : primitive.material().textureReference();
		if (reference.isEmpty())
			throw new IllegalStateException("Primitive has no texture reference");
		try
		{
			if (primitive.material() == null)
				throw new IllegalStateException("Primitive has no material");
			class_2960 texture = PResourceCache.resolve(modelId, reference);
			class_1058 sprite = PResourceCache.getTextureAtlas().method_4608(texture);
			if (sprite.method_45851().method_45816().method_12832().equals("missingno"))
				throw new IllegalStateException("Texture is missing from atlas: " + texture);
			boolean emissive = sprite.method_45851().method_52848().method_43041(PLibMetadata.TYPE).
					map(PLibMetadata::isEmissive).orElse(false);
			try (class_9799 bytes = new class_9799(
					primitive.vertexCount() * PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL.method_1362()))
			{
				class_287 buffer = new AtlasBufferBuilder(bytes, class_293.class_5596.field_27379,
						PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL, sprite);
				for (int vertex = 0; vertex < primitive.vertexCount(); vertex++)
					buffer.method_22912(primitive.positions().get(vertex * 3), primitive.positions().get(vertex * 3 + 1), primitive.positions().get(vertex * 3 + 2)).
									method_22913(primitive.uvs().get(vertex * 2), primitive.uvs().get(vertex * 2 + 1)).
									method_22914(primitive.normals().get(vertex * 3), primitive.normals().get(vertex * 3 + 1), primitive.normals().get(vertex * 3 + 2));
				try (class_9801 meshData = buffer.method_60800())
				{
					PGeometryData geometry = GlGeometryDataFactory.capture(meshData, primitive,
							PRenderTypes.VertexFormatProvider.POSITION_TEX_NORMAL.method_1362());
					builder.meshes.add(new PBakedMesh(meshId, geometry, reference, emissive,
							PTextureAlphaClassifier.resolve(sprite.method_45851()), primitive, texture));
				}
			}
		}
		catch (RuntimeException exception)
		{
			throw new IllegalStateException("Can't bake model " + modelId + " texture " + reference, exception);
		}
	}
	
	private static PBakedBone bakeBone(
			PBakedBone.PBakedBoneBuilder builder,
			@Nullable PBakedBone bakedParent)
	{
		List<PBakedBone> bakedChildren = new ArrayList<>();
		
		PBakedBone bakedBone = new PBakedBone(
				builder.name,
				builder.basePosition,
				builder.baseRotation,
				List.of(),
				bakedParent,
				ImmutableList.copyOf(builder.meshes)
		);
		
		for (PBakedBone.PBakedBoneBuilder child : builder.children)
			bakedChildren.add(bakeBone(child, bakedBone));
		
		return new PBakedBone(
				builder.name,
				builder.basePosition,
				builder.baseRotation,
				ImmutableList.copyOf(bakedChildren),
				bakedParent,
				ImmutableList.copyOf(builder.meshes)
		);
	}
	
	private static CompletableFuture<Void> loadModels(Executor backgroundExecutor,
	                                                  class_3300 resourceManager,
	                                                  BiConsumer<class_2960, PModel> elementConsumer)
	{
		List<CompletableFuture<?>> tasks = new ArrayList<>();
		for (PModelResource resource : PResourceCache.getResourceCache().values())
		{
			PModelLoader loader = getModelLoader(resource.modelLoaderId()).orElseThrow(() ->
					new IllegalStateException("No model loader registered for " + resource.modelId() + ": " + resource.modelLoaderId()));
			tasks.add(loader.loadModel(backgroundExecutor, resourceManager, resource.modelId()).thenAccept(loaded ->
			{
				if (!loaded.modelId().equals(resource.modelId()))
					throw new IllegalStateException("Model loader " + loader.id() + " returned " + loaded.modelId()
							+ " while loading " + resource.modelId());
				PLibDatabase.LOGGER.debug("PulseLib loaded model {} from {} using {}", loaded.modelId(), loaded.source(), loader.id());
				elementConsumer.accept(loaded.modelId(), loaded.model());
			}));
		}

		return CompletableFuture.allOf(tasks.toArray(CompletableFuture[]::new));
	}
}
