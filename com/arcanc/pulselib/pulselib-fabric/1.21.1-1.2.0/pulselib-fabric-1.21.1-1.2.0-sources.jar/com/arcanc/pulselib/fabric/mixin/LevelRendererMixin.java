/**
 * @author ArcAnc
 * Created at: 12.10.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.fabric.mixin;

import com.arcanc.pulselib.content.renderer.PRenderStagesHandler;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_761;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Vanilla 1.21.1 hooks at the exact points used by NeoForge's stage dispatch.
 */
@Mixin (class_761.class)
public abstract class LevelRendererMixin
{
	@Shadow
	private @Nullable class_276 weatherTarget;

	// After block-entity batches and outline processing, immediately before destruction rendering.
	/**
	 * Flushes shared opaque geometry at the Fabric post-block-entity boundary.
	 *
	 * @param callback the Mixin callback used to inspect or replace the intercepted result
	 */
	@Inject (method = "renderLevel", at = @At (value = "INVOKE",
		target = "Lit/unimi/dsi/fastutil/longs/Long2ObjectMap;long2ObjectEntrySet()Lit/unimi/dsi/fastutil/objects/ObjectSet;"))
	private void pulselib$afterBlockEntities(CallbackInfo callback)
	{
		PRenderStagesHandler.afterBlockEntities();
	}

	/**
	 * Flushes shared remaining world geometry after Fabric particle rendering.
	 *
	 * @param callback the Mixin callback used to inspect or replace the intercepted result
	 */
	@Inject (method = "renderLevel", at = @At (value = "INVOKE",
		target = "Lnet/minecraft/client/particle/ParticleEngine;render(Lnet/minecraft/client/renderer/LightTexture;Lnet/minecraft/client/Camera;F)V", shift = At.Shift.AFTER))
	private void pulselib$afterParticles(CallbackInfo callback)
	{
		PRenderStagesHandler.afterParticles();
	}

	/**
	 * Composites deferred translucency into the active weather or main render target.
	 *
	 * @param callback the Mixin callback used to inspect or replace the intercepted result
	 */
	@Inject (method = "renderLevel", at = @At (value = "INVOKE",
		target = "Lnet/minecraft/client/renderer/LevelRenderer;renderSnowAndRain(Lnet/minecraft/client/renderer/LightTexture;FDDD)V", shift = At.Shift.AFTER))
	private void pulselib$afterWeather(CallbackInfo callback)
	{
		PRenderStagesHandler.afterWeather(this.weatherTarget == null ? class_310.method_1551().
				method_1522() : this.weatherTarget);
	}
}
