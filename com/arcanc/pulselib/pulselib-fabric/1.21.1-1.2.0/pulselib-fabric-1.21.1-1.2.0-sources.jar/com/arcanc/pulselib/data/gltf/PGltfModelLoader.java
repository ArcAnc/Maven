/**
 * @author ArcAnc
 * Created at: 27.05.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.data.gltf;

import com.arcanc.pulselib.content.model.PModel;
import com.arcanc.pulselib.data.PLoadedModel;
import com.arcanc.pulselib.data.PModelLoader;
import com.arcanc.pulselib.util.PLibDatabase;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

/**
 * Loads glTF or GLB model resources and optional animation event sidecars.
 */
public class PGltfModelLoader implements PModelLoader
{
	/**
	 * Shared instance of this stateless implementation.
	 */
	public static final PGltfModelLoader INSTANCE = new PGltfModelLoader();

	private static final class_2960 ID = PLibDatabase.rl("gltf");

	private static final String ROOT = "glmodels";
	private static final String GLB_EXTENSION = ".glb";
	private static final String GLTF_EXTENSION = ".gltf";
	private static final String EVENTS_EXTENSION = ".events.json";
	private static final String ANIMATION_EVENTS_EXTENSION = ".animation_events.json";

	private PGltfModelLoader()
	{
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public class_2960 id()
	{
		return ID;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<class_2960> modelResourceCandidates(class_2960 modelId)
	{
		class_2960 source = modelId.method_45138(ROOT + "/");
		return List.of(source.method_48331(GLB_EXTENSION), source.method_48331(GLTF_EXTENSION));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public CompletableFuture<PLoadedModel> loadModel(Executor backgroundExecutor,
	                                                 class_3300 resourceManager,
	                                                 class_2960 modelId)
	{
		return CompletableFuture.supplyAsync(() ->
		{
			class_2960 source = modelResourceCandidates(modelId).stream()
					.filter(candidate -> resourceManager.method_14486(candidate).isPresent())
					.findFirst()
					.orElseThrow(() -> new IllegalStateException(
							"Registered model was not loaded: " + modelId + "; checked resources: "
									+ modelResourceCandidates(modelId)));
			try
			{
				PModel model = PGltfModelParser.parse(resourceManager.getResourceOrThrow(source).method_14482());
				loadAnimationEvents(resourceManager, source, model);
				return new PLoadedModel(modelId, source, model);
			}
			catch (IOException exception)
			{
				throw new RuntimeException("Can't load GLTF model " + source + " for " + modelId, exception);
			}
		}, backgroundExecutor);
	}

	private void loadAnimationEvents(class_3300 resourceManager, class_2960 modelResource, PModel model) throws IOException
	{
		Optional<class_2960> eventsResource = eventCandidates(modelResource).stream()
				.filter(resource -> resourceManager.method_14486(resource).isPresent())
				.findFirst();

		if (eventsResource.isEmpty())
			return;

		PGltfAnimationEventSidecarParser.mergeSidecar(
				PGltfAnimationEventSidecarParser.parseJson(resourceManager.getResourceOrThrow(eventsResource.get()).method_14482()),
				model.animations);
	}

	private List<class_2960> eventCandidates(class_2960 modelResource)
	{
		String modelName = stripModelExtension(modelResource.method_12832()).substring(ROOT.length() + 1);
		String fileName = modelName.substring(modelName.lastIndexOf('/') + 1);

		List<class_2960> candidates = new ArrayList<>();
		candidates.add(modelResource.method_45136(ROOT + "/" + modelName + EVENTS_EXTENSION));
		candidates.add(modelResource.method_45136(ROOT + "/" + modelName + ANIMATION_EVENTS_EXTENSION));
		candidates.add(modelResource.method_45136(ROOT + "/events/" + modelName + EVENTS_EXTENSION));
		candidates.add(modelResource.method_45136(ROOT + "/events/" + fileName + EVENTS_EXTENSION));
		return candidates;
	}

	private static String stripModelExtension(String path)
	{
		if (path.endsWith(GLB_EXTENSION))
			return path.substring(0, path.length() - GLB_EXTENSION.length());
		if (path.endsWith(GLTF_EXTENSION))
			return path.substring(0, path.length() - GLTF_EXTENSION.length());
		return path;
	}
}
