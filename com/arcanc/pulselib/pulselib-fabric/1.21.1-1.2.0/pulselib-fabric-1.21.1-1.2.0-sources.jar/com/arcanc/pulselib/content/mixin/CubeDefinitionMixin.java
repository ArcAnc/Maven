/**
 * @author ArcAnc
 * Created at: 08.08.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.player.deformer.PDeformedCuboid;
import com.arcanc.pulselib.content.player.deformer.PDeformableCubeBakeScope;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;
import net.minecraft.class_2350;
import net.minecraft.class_5604;
import net.minecraft.class_5605;
import net.minecraft.class_5611;
import net.minecraft.class_630;

/**
 * Creates deformable cuboids while baking player model layers inside the deformation bake scope.
 */
@Mixin(class_5604.class)
public class CubeDefinitionMixin
{
	@Shadow @Final
	private Vector3f origin;
	@Shadow @Final
	private Vector3f dimensions;
	@Shadow @Final
	private class_5605 grow;
	@Shadow @Final
	private boolean mirror;
	@Shadow @Final
	private class_5611 texCoord;
	@Shadow @Final
	private class_5611 texScale;
	@Shadow @Final
	private Set<class_2350> visibleFaces;

	/**
	 * Replaces a player-scope baked cube with geometry that supports vertex deformation.
	 *
	 * @param textureWidth the texture width
	 * @param textureHeight the texture height
	 * @param callback the Mixin callback used to inspect or replace the intercepted result
	 */
	@Inject(method = "bake", at = @At("HEAD"), cancellable = true)
	private void pulselib$bakePlayerDeformedCube(int textureWidth, int textureHeight,
												CallbackInfoReturnable<class_630.class_628> callback)
	{
		if (!PDeformableCubeBakeScope.isActive())
			return;
		callback.setReturnValue(new PDeformedCuboid(
				(int)this.texCoord.method_32118(), (int)this.texCoord.method_32119(),
				this.origin.x(), this.origin.y(), this.origin.z(),
				this.dimensions.x(), this.dimensions.y(), this.dimensions.z(),
				this.grow.field_27716, this.grow.field_27717, this.grow.field_27718,
				this.mirror,
				textureWidth * this.texScale.method_32118(), textureHeight * this.texScale.method_32119(), this.visibleFaces));
	}
}
