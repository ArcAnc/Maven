/**
 * @author ArcAnc
 * Created at: 12.10.2026
 * Copyright (c) 2026
 * <p>
 * This code is licensed under "Arc's License of Common Sense"
 * Details can be found in the license file in the root folder of this project
 */

package com.arcanc.pulselib.content.mixin;

import com.arcanc.pulselib.content.event.PulseRuntime;
import net.minecraft.class_3264;
import net.minecraft.class_3304;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Clears runtime state before vanilla resource reload replaces model and texture resources.
 */
@Mixin (class_3304.class)
public abstract class ResourceReloadMixin
{
	@Shadow
	@Final
	private class_3264 type;

	/**
	 * Clears stale runtime state and refreshes plugin model declarations before resource reload.
	 *
	 * @param callback the Mixin callback used to inspect or replace the intercepted result
	 */
	@Inject (method = "createReload", at = @At ("HEAD"))
	private void pulselib$collectModelDeclarations(CallbackInfoReturnable<?> callback)
	{
		if (this.type == class_3264.field_14188)
			PulseRuntime.beforeResourceReload();
	}
}
